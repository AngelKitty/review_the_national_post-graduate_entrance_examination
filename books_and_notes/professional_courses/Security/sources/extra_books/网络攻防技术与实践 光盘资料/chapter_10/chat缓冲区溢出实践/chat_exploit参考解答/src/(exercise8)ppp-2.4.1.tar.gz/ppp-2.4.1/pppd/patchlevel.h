/* $Id: patchlevel.h,v 1.53 2001/03/25 04:51:54 paulus Exp $ */

#define VERSION		"2.4.1"
#define DATE		"25 March 2001"
