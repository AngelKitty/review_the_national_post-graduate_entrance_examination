#include <stdio.h>

int main(int argc, char**argv)
{
	char buf[10];
	strcpy(buf,argv[1]);
	printf("buf @@ 0x%08x\n",&buf);
	getchar();
	return 0;
}