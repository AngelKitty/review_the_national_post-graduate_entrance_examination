void DbgMsg(char *file, int line, char *msg, ...);
