#include "stdafx.h"
#include "objbase.h"
#include "objsafe.h"
#include <iostream>
#include <sstream>
#include <tchar.h>

/* The TypeLib info stuff has been ripped from Sean Baxter:
http://spec.winprog.org/typeinf2/
*/
DEFINE_GUID(IID_IDispatchEx, 0xA6EF9860, 0xC720, 0x11D0, 0x93, 0x37, 
			0x00, 0xA0, 0xC9, 0x0D, 0xCA, 0xA9);

CLSID clsid;
#define IMPLTYPE_MASK \
(IMPLTYPEFLAG_FDEFAULT | IMPLTYPEFLAG_FSOURCE | IMPLTYPEFLAG_FRESTRICTED)

std::string stringifyCustomType(HREFTYPE refType, ITypeInfo* pti) {
	ITypeInfo *pTypeInfo(pti);
	ITypeInfo *pCustTypeInfo;
	HRESULT hr(pTypeInfo->GetRefTypeInfo(refType, &pCustTypeInfo));
	if(hr) return "UnknownCustomType";
	BSTR bstrType;
	hr = pCustTypeInfo->GetDocumentation(-1, &bstrType, 0, 0, 0);
	if(hr) return "UnknownCustomType";
	char ansiType[MAX_PATH];
	WideCharToMultiByte(CP_ACP, 0, bstrType, -1, ansiType, MAX_PATH, 0, 0);
	if(bstrType) ::SysFreeString(bstrType);
	pCustTypeInfo->Release();
	return ansiType;
}

std::string stringifyTypeDesc(TYPEDESC* typeDesc, ITypeInfo* pTypeInfo) {
	std::ostringstream oss;
	if(typeDesc->vt == VT_PTR) {
		oss<< stringifyTypeDesc(typeDesc->lptdesc, pTypeInfo)<< '*';
		return oss.str();
	}
	if(typeDesc->vt == VT_SAFEARRAY) {
		oss<< "SAFEARRAY("
			<< stringifyTypeDesc(typeDesc->lptdesc, pTypeInfo)<< ')';
		return oss.str();
	}
	if(typeDesc->vt == VT_CARRAY) {
		oss<< stringifyTypeDesc(&typeDesc->lpadesc->tdescElem, pTypeInfo);
		for(int dim(0); typeDesc->lpadesc->cDims; ++dim) 
			oss<< '['<< typeDesc->lpadesc->rgbounds[dim].lLbound<< "..."
			<< (typeDesc->lpadesc->rgbounds[dim].cElements + 
			typeDesc->lpadesc->rgbounds[dim].lLbound - 1)<< ']';
		return oss.str();
	}
	if(typeDesc->vt == VT_USERDEFINED) {
		oss<< stringifyCustomType(typeDesc->hreftype, pTypeInfo);
		return oss.str();
	}

	switch(typeDesc->vt) {
		// VARIANT/VARIANTARG compatible types
	case VT_I2: return "short";
	case VT_I4: return "long";
	case VT_R4: return "float";
	case VT_R8: return "double";
	case VT_CY: return "CY";
	case VT_DATE: return "DATE";
	case VT_BSTR: return "BSTR";
	case VT_DISPATCH: return "IDispatch*";
	case VT_ERROR: return "SCODE";
	case VT_BOOL: return "VARIANT_BOOL";
	case VT_VARIANT: return "VARIANT";
	case VT_UNKNOWN: return "IUnknown*";
	case VT_UI1: return "BYTE";
	case VT_DECIMAL: return "DECIMAL";
	case VT_I1: return "char";
	case VT_UI2: return "USHORT";
	case VT_UI4: return "ULONG";
	case VT_I8: return "__int64";
	case VT_UI8: return "unsigned __int64";
	case VT_INT: return "int";
	case VT_UINT: return "UINT";
	case VT_HRESULT: return "HRESULT";
	case VT_VOID: return "void";
	case VT_LPSTR: return "char*";
	case VT_LPWSTR: return "wchar_t*";
	}
	return "BIG ERROR!";
}

int displayTypeInfo(IDispatch *dptr)
{
	ITypeInfo *pTypeInfo;
	HRESULT hr = dptr->GetTypeInfo(0, 0, &pTypeInfo);
	if(hr) { fprintf(stderr, "Object doesn't supply type info\n\n"); return -1; }

	TYPEATTR* typeAttr;
	pTypeInfo->GetTypeAttr(&typeAttr);

	BSTR interfaceName;
	hr = pTypeInfo->GetDocumentation(-1, &interfaceName, 0, 0, 0);
	if(hr) fprintf(stderr,"Unknown default interface:\n");
	else
	{
		wprintf(L"     %s:\n", interfaceName);
	}
	if(interfaceName) ::SysFreeString(interfaceName);

	for(UINT curFunc(0); curFunc < typeAttr->cFuncs; ++curFunc) {
		FUNCDESC* funcDesc;
		hr = pTypeInfo->GetFuncDesc(curFunc, &funcDesc);

		//Skip restricted methods
		if (!(funcDesc->wFuncFlags & 1))
		{
			BSTR methodName;
			hr |= pTypeInfo->GetDocumentation(funcDesc->memid, &methodName, 0, 0, 0);
			if(hr) { fprintf(stderr, "Error In Name\n"); 
			pTypeInfo->ReleaseFuncDesc(funcDesc); continue; }

			printf("\t%s ", stringifyTypeDesc(&funcDesc->elemdescFunc.tdesc,pTypeInfo).c_str());
			wprintf(L"%s(", methodName);
			if(methodName) ::SysFreeString(methodName);
			for(UINT curParam(0); curParam < funcDesc->cParams; ++curParam) {
				printf("%s", stringifyTypeDesc(&funcDesc->lprgelemdescParam[curParam].tdesc, pTypeInfo).c_str());
				if(curParam < funcDesc->cParams - 1) printf(", ");
			}
			printf(")");

			switch(funcDesc->invkind) {
			case INVOKE_PROPERTYGET: printf(" propget"); break;
			case INVOKE_PROPERTYPUT: printf(" propput"); break;
			case INVOKE_PROPERTYPUTREF: printf(" propputref"); break;
			}

			bool invFlag = true;
			if (funcDesc->invkind == INVOKE_FUNC)
			{
				for (int j = 0; j < funcDesc->cParams; j++)
				{
					if (funcDesc->lprgelemdescParam[j].tdesc.vt != VT_BSTR && 
						funcDesc->lprgelemdescParam[j].tdesc.vt != VT_I4)
						invFlag = false;			
				}
				//Comment out this line if you want to try invoke the methods:
				invFlag = false;

				if (invFlag && funcDesc->cParams > 0)
				{
					DISPPARAMS params;
					memset(&params, 0, sizeof params);
					char largec[2052];
					WCHAR largew[2052];
					memset(largec, 'A', sizeof(largec));
					largec[2051] = '\0';
					MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, largec, -1, largew, 2052);
					params.cArgs = funcDesc->cParams;
					params.cNamedArgs = 0;
					BSTR argval;
					argval = ::SysAllocString(largew);
					// allocate memory for all VARIANT parameters
					VARIANT *pArg = new VARIANT[params.cArgs];
					params.rgvarg = pArg;
					memset(pArg, 0, sizeof(VARIANT) * params.cArgs); 
					for (int i = 0; i < params.cArgs; i++)
					{
						if (funcDesc->lprgelemdescParam[i].tdesc.vt == VT_BSTR)
						{
							pArg[i].bstrVal = argval;
							pArg[i].vt = VT_BSTR;
						} else //VT_I4
						{
							pArg[i].lVal = 0;
							pArg[i].vt = VT_I4;
						}
					}
					VARIANT Result;
					Result.vt=VT_BOOL;
					Result.boolVal=VARIANT_FALSE;
					EXCEPINFO excep;
					UINT uArgErr;

					try {
						dptr->Invoke(funcDesc->memid, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &params,NULL,NULL,&uArgErr);
					} catch (...)
					{
						printf("\n\n\n***************************Possible exploit*******************\n\n\n\
*********************************************************************\n\n");
						//scanf("%s");
					}

					printf(" ->Called");

					::SysFreeString(argval);
					delete pArg;
				}
			}
			printf("\n");
		}

		pTypeInfo->ReleaseFuncDesc(funcDesc);
	}

pTypeInfo->ReleaseTypeAttr(typeAttr);
pTypeInfo->Release();
return 0;
}


int _tmain(int argc, _TCHAR* argv[])
{
	IObjectSafety *pOSafe = NULL;
	HKEY hKey;
	HKEY hKeyQ;
	DWORD dwBufLen = MAX_PATH;
	DWORD cbName = MAX_PATH;
	TCHAR achKey[MAX_PATH];
	WCHAR clsidstring[MAX_PATH];
	TCHAR regkey[1024];
	DWORD cSubKeys;
	FILETIME ftime;
	DWORD cbData = MAX_PATH;
	BYTE rData[MAX_PATH]; 
	DWORD tp;

	RegOpenKeyEx(HKEY_LOCAL_MACHINE, TEXT("Software\\Classes\\CLSID"), 0, KEY_READ, &hKey );

	RegQueryInfoKey(
		hKey,                    // key handle 
		NULL,                // buffer for class name 
		NULL,           // size of class string 
		NULL,                    // reserved 
		&cSubKeys,               // number of subkeys 
		NULL,            // longest subkey size 
		NULL,            // longest class string 
		NULL,                // number of values for this key 
		NULL,            // longest value name 
		NULL,         // longest value data 
		NULL,   // security descriptor 
		NULL);       // last write time 

	CoInitialize(NULL);

	DWORD j = 0;
	if (argc > 1)
	{
		for (j = 0; j<cSubKeys; j++)
		{
			cbName=MAX_PATH;
			achKey[0] = '\0';
			RegEnumKeyEx(hKey, j,
				achKey, 
				&cbName, 
				NULL, 
				NULL, 
				NULL, 
				&ftime); 

			if (!strncmp(achKey, argv[1], MAX_PATH))
				break;
		}
	}

	for (DWORD i = j+1; i<cSubKeys; i++)
	{
		cbName=MAX_PATH;
		achKey[0] = '\0';
		RegEnumKeyEx(hKey, i,
			achKey, 
			&cbName, 
			NULL, 
			NULL, 
			NULL, 
			&ftime); 

		MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, achKey, -1, clsidstring, MAX_PATH);
		CLSIDFromString(clsidstring, &clsid);

		sprintf(regkey, "Software\\Classes\\CLSID\\%s", achKey);
		RegOpenKeyEx(HKEY_LOCAL_MACHINE, regkey, 0, KEY_QUERY_VALUE, &hKeyQ );
		cbData = MAX_PATH;
		LONG retVal = RegQueryValueEx(hKeyQ, NULL, NULL, &tp, rData, &cbData );
		RegCloseKey(hKeyQ);
		fprintf(stderr, "%s", achKey);
		if (retVal == ERROR_SUCCESS)
			fprintf(stderr, " - %s",  (char*)rData);

		fprintf(stderr, "\n");
		fflush(stderr);
		fflush(stdout);
		bool typedisplayed = false;

		try {

			HRESULT hr = CoCreateInstance(clsid, NULL, CLSCTX_LOCAL_SERVER | CLSCTX_INPROC_SERVER, IID_IObjectSafety, (void**)&pOSafe);
			if (hr == S_OK)
			{
				if (retVal == ERROR_SUCCESS)
				{
					printf("\n> %s\n", (char*)rData);
					printf("     %s\n", achKey);
				}
				else
					printf("\n> %s\n", achKey);

				DWORD dwSupported = 0;
				DWORD dwEnabled = 0;

				printf("     IObjectSafety:\n", achKey);
				HRESULT hsd = pOSafe->SetInterfaceSafetyOptions(IID_IPersist, INTERFACESAFE_FOR_UNTRUSTED_DATA, INTERFACESAFE_FOR_UNTRUSTED_DATA);
				if (hsd == S_OK)
				{
					printf("     IO. Safe for initialization set successfully\n");
					pOSafe->GetInterfaceSafetyOptions(IID_IPersist, &dwSupported, &dwEnabled);
					printf("     IPersist:GetInterfaceSafetyOptions Supported=%x, Enabled=%x\n",dwSupported, dwEnabled);
				}
				hsd = pOSafe->SetInterfaceSafetyOptions(IID_IDispatchEx, INTERFACESAFE_FOR_UNTRUSTED_CALLER, INTERFACESAFE_FOR_UNTRUSTED_CALLER);
				if (hsd == S_OK)
				{
					printf("     IO. Safe for scripting (IDispatchEx) set successfully\n");
					pOSafe->GetInterfaceSafetyOptions(IID_IDispatchEx, &dwSupported, &dwEnabled);
					printf("     IDispatchEx:GetInterfaceSafetyOptions Supported=%x, Enabled=%x\n",dwSupported, dwEnabled);
				}
				else {
					hsd = pOSafe->SetInterfaceSafetyOptions(IID_IDispatch, INTERFACESAFE_FOR_UNTRUSTED_CALLER, INTERFACESAFE_FOR_UNTRUSTED_CALLER);
					if (hsd == S_OK)
					{
						printf("     IO. Safe for scripting (IDispatch) set successfully\n");
						pOSafe->GetInterfaceSafetyOptions(IID_IDispatch, &dwSupported, &dwEnabled);
						printf("     IDispatch:GetInterfaceSafetyOptions Supported=%x, Enabled=%x\n",dwSupported, dwEnabled);
					}
				}

				IDispatch *dptr;
				pOSafe->QueryInterface(IID_IDispatch, (void**)&dptr);
				if (hr == S_OK)
				{
					displayTypeInfo(dptr);
					dptr->Release();
				}
				typedisplayed = true;
				pOSafe->Release();
			}

			sprintf(regkey, "Software\\Classes\\CLSID\\%s\\Implemented Categories\\{7DD95801-9882-11CF-9FA9-00AA006C42C4}", achKey);
			LONG retValScripting = RegOpenKeyEx(HKEY_LOCAL_MACHINE, regkey, 0, KEY_QUERY_VALUE, &hKeyQ );
			RegCloseKey(hKeyQ);
			sprintf(regkey, "Software\\Classes\\CLSID\\%s\\Implemented Categories\\{7DD95802-9882-11CF-9FA9-00AA006C42C4}", achKey);
			LONG retValIniting = RegOpenKeyEx(HKEY_LOCAL_MACHINE, regkey, 0, KEY_QUERY_VALUE, &hKeyQ );
			RegCloseKey(hKeyQ);

			if (retValIniting == ERROR_SUCCESS || retValScripting == ERROR_SUCCESS)
			{
				if (retVal == ERROR_SUCCESS)
				{
					printf("\n+ %s\n", (char*)rData);
					printf("     %s\n", achKey);
				}
				else
					printf("\n+ %s\n", achKey);

				printf("     Implemented Categories:\n");


				if (retValIniting == ERROR_SUCCESS)
					printf("     Category: Safe for Initialising\n");

				if (retValScripting == ERROR_SUCCESS)
					printf("     Category: Safe for Scripting\n");

				if (!typedisplayed)
				{
					IDispatch *dptr;
					hr = CoCreateInstance(clsid, NULL, CLSCTX_LOCAL_SERVER | CLSCTX_INPROC_SERVER, IID_IDispatch, (void**)&dptr);
					if (hr == S_OK)
					{
						displayTypeInfo(dptr);
						dptr->Release();
					}
				}		
			}
		} catch (...)
		{
			//An exception in a COM server can be used as an DoS
			printf("\n* Exception occurred **** \n**** %s\n", achKey);
			if (retVal == ERROR_SUCCESS)
				printf("**** %s\n\n", (char*)rData);
		}
	}

	RegCloseKey(hKey);
	CoUninitialize();
	return 0;
}