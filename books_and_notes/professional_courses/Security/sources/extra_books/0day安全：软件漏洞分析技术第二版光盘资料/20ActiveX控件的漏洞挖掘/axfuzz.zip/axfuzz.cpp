#include "stdafx.h"
#include "objbase.h"
#include "objsafe.h"
#include <iostream>
#include <sstream>

/* The TypeLib info stuff has been ripped from Sean Baxter:
http://spec.winprog.org/typeinf2/
*/

DEFINE_GUID(IID_IDispatchEx, 0xA6EF9860, 0xC720, 0x11D0, 0x93, 0x37, 
			0x00, 0xA0, 0xC9, 0x0D, 0xCA, 0xA9);

CLSID clsid;
#define IMPLTYPE_MASK \
	(IMPLTYPEFLAG_FDEFAULT | IMPLTYPEFLAG_FSOURCE | IMPLTYPEFLAG_FRESTRICTED)

int arrsize = 0;
BSTR largeString;
int fuzzdispatch(IDispatch *dptr);

std::string stringifyCustomType(HREFTYPE refType, ITypeInfo* pti) {
	ITypeInfo *pTypeInfo(pti);
	ITypeInfo *pCustTypeInfo;
	HRESULT hr(pTypeInfo->GetRefTypeInfo(refType, &pCustTypeInfo));
	if(hr) return "UnknownCustomType";
	BSTR bstrType;
	hr = pCustTypeInfo->GetDocumentation(-1, &bstrType, 0, 0, 0);
	if(hr) return "UnknownCustomType";
	char ansiType[MAX_PATH];
	WideCharToMultiByte(CP_ACP, 0, bstrType, -1, ansiType, MAX_PATH, 0, 0);
	if(bstrType) ::SysFreeString(bstrType);
	pCustTypeInfo->Release();
	return ansiType;
}

std::string stringifyTypeDesc(TYPEDESC* typeDesc, ITypeInfo* pTypeInfo) {
	std::ostringstream oss;
	if(typeDesc->vt == VT_PTR) {
		oss<< stringifyTypeDesc(typeDesc->lptdesc, pTypeInfo)<< '*';
		return oss.str();
	}
	if(typeDesc->vt == VT_SAFEARRAY) {
		oss<< "SAFEARRAY("
			<< stringifyTypeDesc(typeDesc->lptdesc, pTypeInfo)<< ')';
		return oss.str();
	}
	if(typeDesc->vt == VT_CARRAY) {
		oss<< stringifyTypeDesc(&typeDesc->lpadesc->tdescElem, pTypeInfo);
		for(int dim(0); typeDesc->lpadesc->cDims; ++dim) 
			oss<< '['<< typeDesc->lpadesc->rgbounds[dim].lLbound<< "..."
			<< (typeDesc->lpadesc->rgbounds[dim].cElements + 
			typeDesc->lpadesc->rgbounds[dim].lLbound - 1)<< ']';
		return oss.str();
	}
	if(typeDesc->vt == VT_USERDEFINED) {
		oss<< stringifyCustomType(typeDesc->hreftype, pTypeInfo);
		return oss.str();
	}

	switch(typeDesc->vt) {
		// VARIANT/VARIANTARG compatible types
	case VT_I2: return "short";
	case VT_I4: return "long";
	case VT_R4: return "float";
	case VT_R8: return "double";
	case VT_CY: return "CY";
	case VT_DATE: return "DATE";
	case VT_BSTR: return "BSTR";
	case VT_DISPATCH: return "IDispatch*";
	case VT_ERROR: return "SCODE";
	case VT_BOOL: return "VARIANT_BOOL";
	case VT_VARIANT: return "VARIANT";
	case VT_UNKNOWN: return "IUnknown*";
	case VT_UI1: return "BYTE";
	case VT_DECIMAL: return "DECIMAL";
	case VT_I1: return "char";
	case VT_UI2: return "USHORT";
	case VT_UI4: return "ULONG";
	case VT_I8: return "__int64";
	case VT_UI8: return "unsigned __int64";
	case VT_INT: return "int";
	case VT_UINT: return "UINT";
	case VT_HRESULT: return "HRESULT";
	case VT_VOID: return "void";
	case VT_LPSTR: return "char*";
	case VT_LPWSTR: return "wchar_t*";
	}
	return "BIG ERROR!";
}

int displayTypeInfo(IDispatch *dptr)
{
	ITypeInfo *pTypeInfo;
	HRESULT hr = dptr->GetTypeInfo(0, 0, &pTypeInfo);
	if(hr) { fprintf(stderr, "Object doesn't supply type info\n\n"); return -1; }

	TYPEATTR* typeAttr;
	pTypeInfo->GetTypeAttr(&typeAttr);

	BSTR interfaceName;
	hr = pTypeInfo->GetDocumentation(-1, &interfaceName, 0, 0, 0);
	if(hr) fprintf(stderr,"Unknown default interface:\n");
	else
	{
		wprintf(L"     %s:\n", interfaceName);
	}
	if(interfaceName) ::SysFreeString(interfaceName);

	for(UINT curFunc(0); curFunc < typeAttr->cFuncs; ++curFunc) {
		FUNCDESC* funcDesc;
		hr = pTypeInfo->GetFuncDesc(curFunc, &funcDesc);

		//Skip restricted methods
		if (!(funcDesc->wFuncFlags & 1))
		{
			BSTR methodName;
			hr |= pTypeInfo->GetDocumentation(funcDesc->memid, &methodName, 0, 0, 0);
			if(hr) { fprintf(stderr, "Error In Name\n"); 
			pTypeInfo->ReleaseFuncDesc(funcDesc); continue; }

			printf("\t%s ", stringifyTypeDesc(&funcDesc->elemdescFunc.tdesc,pTypeInfo).c_str());
			wprintf(L"%s(", methodName);
			if(methodName) ::SysFreeString(methodName);
			for(UINT curParam(0); curParam < funcDesc->cParams; ++curParam) {
				printf("%s", stringifyTypeDesc(&funcDesc->lprgelemdescParam[curParam].tdesc, pTypeInfo).c_str());
				if(curParam < funcDesc->cParams - 1) printf(", ");
			}
			printf(")");

			switch(funcDesc->invkind) {
				case INVOKE_PROPERTYGET: printf(" propget"); break;
				case INVOKE_PROPERTYPUT: printf(" propput"); break;
				case INVOKE_PROPERTYPUTREF: printf(" propputref"); break;
			}


			printf("\n");
		}
		pTypeInfo->ReleaseFuncDesc(funcDesc);
	}

	pTypeInfo->ReleaseTypeAttr(typeAttr);
	pTypeInfo->Release();
	return 0;
}

int fuzzmethod(IDispatch *dptr,ITypeInfo *pTypeInfo, FUNCDESC* funcDesc)
{
	HRESULT hr = S_OK;
	bool invFlag = true;
	VARIANT *pArg = NULL;
/*
	for (int j = 0; j < funcDesc->cParams; j++)
	{
		if (funcDesc->lprgelemdescParam[j].tdesc.vt != VT_BSTR && 
			funcDesc->lprgelemdescParam[j].tdesc.vt != VT_I4)
			invFlag = false;			
	}
*/
	if (invFlag)
	{
		printf("       Calling ");

		BSTR methodName;
		hr |= pTypeInfo->GetDocumentation(funcDesc->memid, &methodName, 0, 0, 0);
		if(hr) { fprintf(stderr, "Error In Name\n");

		pTypeInfo->ReleaseFuncDesc(funcDesc); return -1; }

		printf("%s ", stringifyTypeDesc(&funcDesc->elemdescFunc.tdesc,pTypeInfo).c_str());
		wprintf(L"%s(", methodName);
		if(methodName) ::SysFreeString(methodName);
		for(UINT curParam(0); curParam < funcDesc->cParams; ++curParam) {
			printf("%s", stringifyTypeDesc(&funcDesc->lprgelemdescParam[curParam].tdesc, pTypeInfo).c_str());
			if(curParam < funcDesc->cParams - 1) printf(", ");
		}

		printf(")");

		DISPPARAMS params;
		memset(&params, 0, sizeof params);

		params.cArgs = funcDesc->cParams;
		params.cNamedArgs = 0;
		params.rgvarg = NULL;

		if (params.cArgs > 0)
		{
			// allocate memory for all VARIANT parameters
			pArg = new VARIANT[params.cArgs];

			params.rgvarg = pArg;
			memset(pArg, 0, sizeof(VARIANT) * params.cArgs); 

			for (int i = 0; i < params.cArgs; i++)
			{
				VariantInit(&pArg[i]);
				if (funcDesc->lprgelemdescParam[i].tdesc.vt == VT_BSTR)
				{
					pArg[i].bstrVal = largeString;
					pArg[i].vt = VT_BSTR;
				} else 
				{
					pArg[i].vt = funcDesc->lprgelemdescParam[i].tdesc.vt;
				}
			}
		}

		VARIANT Result;
		VariantInit(&Result);
		Result.vt=VT_BOOL;
		Result.boolVal=VARIANT_FALSE;
		EXCEPINFO excep;
		UINT uArgErr;

		try {
			dptr->Invoke(funcDesc->memid, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &params, &Result,NULL,&uArgErr);
		} catch (...)
		{
			printf(" ********* Crashed...");
		}

		printf(" ->Called");
		if (Result.vt == VT_DISPATCH && !Result.pdispVal)
			printf(" no result");

		if (Result.vt == VT_DISPATCH && Result.pdispVal)
		{
			//infinite recursion possible
			fuzzdispatch(Result.pdispVal);
			Result.pdispVal->Release();
		}

		try {
				VariantClear(&Result);
		} catch(...)
		{
			printf("Crash freeing result");
		}
		printf("\n");
		delete pArg;
	}
	return 0;
}

//Does the methods - after all properties are set
int fuzzmethods(IDispatch *dptr)
{
	ITypeInfo *pTypeInfo;
	IDispatch *rdptr;

	HRESULT hr = dptr->GetTypeInfo(0, 0, &pTypeInfo);
	if(hr) { fprintf(stderr, "Object doesn't supply type info\n\n"); return -1; }

	TYPEATTR* typeAttr;
	pTypeInfo->GetTypeAttr(&typeAttr);

	BSTR interfaceName;
	hr = pTypeInfo->GetDocumentation(-1, &interfaceName, 0, 0, 0);
	if(hr) fprintf(stderr,"Unknown default interface:\n");
	else
	{
		wprintf(L"     Fuzzing methods for %s:\n", interfaceName);
	}
	for(UINT curFunc(0); curFunc < typeAttr->cFuncs; ++curFunc) {
		FUNCDESC* funcDesc;
		hr = pTypeInfo->GetFuncDesc(curFunc, &funcDesc);

		//Skip restricted methods
		if (!(funcDesc->wFuncFlags & 1))
		{
			if (funcDesc->invkind == INVOKE_FUNC)
				fuzzmethod(dptr, pTypeInfo, funcDesc);
		}
		pTypeInfo->ReleaseFuncDesc(funcDesc);
	}
	return 0;
}

//Sets all properties, then calls fuzzmethods to call all methods.
//Recursive function
int fuzzdispatch(IDispatch *dptr)
{
	ITypeInfo *pTypeInfo;
	IDispatch *rdptr;
	VARIANT *pArg = NULL;

	//Ironically this program contains many buffer overflows...
	char ans[10];
	printf(" Fuzz dispatch? (y/n) ");
	scanf("%s", ans);
	if (!strncmp(ans, "n", 1))
		return 0;

	HRESULT hr = dptr->GetTypeInfo(0, 0, &pTypeInfo);
	if(hr) { fprintf(stderr, "Object doesn't supply type info\n\n"); return -1; }

	TYPEATTR* typeAttr;
	pTypeInfo->GetTypeAttr(&typeAttr);

	BSTR interfaceName;
	hr = pTypeInfo->GetDocumentation(-1, &interfaceName, 0, 0, 0);
	if(hr) fprintf(stderr,"Unknown default interface:\n");
	else
	{
		wprintf(L"\n     Fuzzing properties for %s:\n", interfaceName);
	}

	for(UINT curFunc(0); curFunc < typeAttr->cFuncs; ++curFunc) {
		FUNCDESC* funcDesc;
		hr = pTypeInfo->GetFuncDesc(curFunc, &funcDesc);

		//Skip restricted methods
		if (!(funcDesc->wFuncFlags & 1))
		{
			BSTR methodName;
			hr |= pTypeInfo->GetDocumentation(funcDesc->memid, &methodName, 0, 0, 0);
			if(hr) { fprintf(stderr, "Error In Name\n"); 
			pTypeInfo->ReleaseFuncDesc(funcDesc); continue; }

			printf("\t%s ", stringifyTypeDesc(&funcDesc->elemdescFunc.tdesc,pTypeInfo).c_str());
			wprintf(L"%s(", methodName);
			if(methodName) ::SysFreeString(methodName);
			for(UINT curParam(0); curParam < funcDesc->cParams; ++curParam) {
				printf("%s", stringifyTypeDesc(&funcDesc->lprgelemdescParam[curParam].tdesc, pTypeInfo).c_str());
				if(curParam < funcDesc->cParams - 1) printf(", ");
			}
			printf(")");

			switch(funcDesc->invkind) {
				case INVOKE_PROPERTYGET: printf(" propget"); break;
				case INVOKE_PROPERTYPUT: printf(" propput"); break;
				case INVOKE_PROPERTYPUTREF: printf(" propputref"); break;
			}

			//Try get every property. 
			if (funcDesc->invkind == INVOKE_PROPERTYGET)
			{
					DISPPARAMS params;
					params.cArgs = 0;
					params.cNamedArgs = 0;
					params.rgvarg = NULL;

					memset(&params, 0, sizeof params);

					params.cArgs = funcDesc->cParams;
					params.cNamedArgs = 0;
					params.rgvarg = NULL;

					if (params.cArgs > 0)
					{
						// allocate memory for all VARIANT parameters
						pArg = new VARIANT[params.cArgs];

						params.rgvarg = pArg;
						memset(pArg, 0, sizeof(VARIANT) * params.cArgs); 

						for (int i = 0; i < params.cArgs; i++)
						{
							VariantInit(&pArg[i]);
							if (funcDesc->lprgelemdescParam[i].tdesc.vt == VT_BSTR)
							{
								pArg[i].bstrVal = largeString;
								pArg[i].vt = VT_BSTR;
							} else 
							{
								pArg[i].vt = funcDesc->lprgelemdescParam[i].tdesc.vt;
						}
						}
					}

					VARIANT Result;
					Result.vt=VT_PTR;
					Result.pdispVal=NULL;
					EXCEPINFO excep;
					UINT uArgErr;
					try {
						dptr->Invoke(funcDesc->memid, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_PROPERTYGET, &params,&Result,NULL,&uArgErr);
					} catch (...)
					{
						printf("*********** Crashed...");
					}
					
					printf (" <-Got");
					if (pArg) delete pArg;
					pArg = NULL;
					
					if (Result.vt == VT_PTR && !Result.pdispVal)
						printf(" no result");

					//Attempt to recursively fuzz an interface returned from a property
					if (Result.vt == VT_DISPATCH && Result.pdispVal)
					{
						//infinite recursion possible
						fuzzdispatch(Result.pdispVal);
						Result.pdispVal->Release();
					}

					//Should free Result Variant... but causes crashes
					try {
						VariantClear(&Result);
					} catch(...)
					{
						printf("Crash freeing result");
					}
			}

			if (funcDesc->invkind == INVOKE_PROPERTYPUT)
			{
				DISPPARAMS params;
				params.cArgs = 1;
				params.cNamedArgs = 0;
				memset(&params, 0, sizeof params);

				params.cArgs = funcDesc->cParams;
				params.cNamedArgs = 0;
				params.rgvarg = NULL;

				if (params.cArgs > 0)
				{
					// allocate memory for all VARIANT parameters
					pArg = new VARIANT[params.cArgs];

					params.rgvarg = pArg;
					memset(pArg, 0, sizeof(VARIANT) * params.cArgs); 

					for (int i = 0; i < params.cArgs; i++)
					{
						VariantInit(&pArg[i]);
						if (funcDesc->lprgelemdescParam[i].tdesc.vt == VT_BSTR)
						{
							pArg[i].bstrVal = largeString;
							pArg[i].vt = VT_BSTR;
						} else 
						{
							pArg[i].vt = funcDesc->lprgelemdescParam[i].tdesc.vt;

							if (pArg[i].vt == VT_BOOL)
								pArg[i].boolVal = VARIANT_TRUE;

							if (pArg[i].vt == VT_I4)
								pArg[i].lVal = 1;

							if (pArg[i].vt == VT_INT)
								pArg[i].intVal = 1;

						}
					}
				}
				VARIANT Result;
				Result.vt=VT_BOOL;
				Result.boolVal=VARIANT_FALSE;

				EXCEPINFO excep;
				UINT uArgErr;

				try {
					dptr->Invoke(funcDesc->memid, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_PROPERTYPUT, &params,&Result,NULL,&uArgErr);
				} catch (...)
				{
					printf("************* Crashed...");
				}
				printf (" <-Set");
				if (pArg) delete pArg; //dont want to free our large bstr, so dont use variantclear
				pArg = NULL;
			}
			printf("\n");
			pTypeInfo->ReleaseFuncDesc(funcDesc);
		}
	}

	//Now call all methods
	fuzzmethods(dptr);

	if(interfaceName)
	{
		wprintf(L"     End %s\n",interfaceName);
		::SysFreeString(interfaceName);
	}
	pTypeInfo->ReleaseTypeAttr(typeAttr);
	pTypeInfo->Release();
	return 0;
}

int _tmain(int argc, _TCHAR* argv[])
{
	IObjectSafety *pOSafe = NULL;
	HKEY hKey;
	HKEY hKeyQ;
	DWORD dwBufLen = MAX_PATH;
	DWORD cbName = MAX_PATH;
	WCHAR clsidstring[MAX_PATH];
	TCHAR regkey[1024];
	DWORD cSubKeys;
	FILETIME ftime;
	DWORD cbData = MAX_PATH;
	BYTE rData[MAX_PATH]; 
	DWORD tp;

	CoInitialize(NULL);

	if (argc < 3)
	{
		printf ("Usage: %s ArraySize CLSID \n", argv[0]);
		printf ("%s 1000 {00CLSID00-000-000-00}\n", argv[0]);
		return -1;
	}

	arrsize= atoi(argv[1]);

	//Terrible way to get a large BSTR
	char *largec = new char[arrsize];
	WCHAR *largew = new WCHAR[arrsize];
	memset(largec, 'A', arrsize);
	largec[arrsize-1] = '\0';
	MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, largec, -1, largew, arrsize);
	delete largec;
	largeString = ::SysAllocString(largew);
	delete largew;

	MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, argv[2], -1, clsidstring, MAX_PATH);
	CLSIDFromString(clsidstring, &clsid);
	sprintf(regkey, "Software\\Classes\\CLSID\\%s", argv[2]);
	RegOpenKeyEx(HKEY_LOCAL_MACHINE, regkey, 0, KEY_QUERY_VALUE, &hKeyQ );
	cbData = MAX_PATH;
	LONG retVal = RegQueryValueEx(hKeyQ, NULL, NULL, &tp, rData, &cbData );
	RegCloseKey(hKeyQ);
	fprintf(stderr, "%s", argv[2]);

	if (retVal == ERROR_SUCCESS)
		fprintf(stderr, " - %s",  (char*)rData);

	bool typedisplayed = false;

	//try {

		HRESULT hr = CoCreateInstance(clsid, NULL, CLSCTX_LOCAL_SERVER | CLSCTX_INPROC_SERVER, IID_IObjectSafety, (void**)&pOSafe);
		if (hr == S_OK)
		{
			if (retVal == ERROR_SUCCESS)
			{
				printf("\n> %s\n", (char*)rData);
				printf("     %s\n", argv[2]);
			}
			else
				printf("\n> %s\n", argv[2]);

			printf("     IObjectSafety:\n", argv[1]);

			HRESULT hsd = pOSafe->SetInterfaceSafetyOptions(IID_IPersist, INTERFACESAFE_FOR_UNTRUSTED_DATA, INTERFACESAFE_FOR_UNTRUSTED_DATA);
			if (hsd == S_OK)
				printf("     IO. Safe for initialization\n");

			hsd = pOSafe->SetInterfaceSafetyOptions(IID_IDispatchEx, INTERFACESAFE_FOR_UNTRUSTED_CALLER, INTERFACESAFE_FOR_UNTRUSTED_CALLER);
			if (hsd == S_OK)
				printf("     IO. Safe for scripting (IDispatchEx)\n");
			else {
				hsd = pOSafe->SetInterfaceSafetyOptions(IID_IDispatch, INTERFACESAFE_FOR_UNTRUSTED_CALLER, INTERFACESAFE_FOR_UNTRUSTED_CALLER);
				if (hsd == S_OK)
					printf("     IO. Safe for scripting (IDispatch)\n");
			}

			IDispatch *dptr;
			pOSafe->QueryInterface(IID_IDispatch, (void**)&dptr);
			if (hr == S_OK)
			{
				displayTypeInfo(dptr);
				fuzzdispatch(dptr);
				dptr->Release();
			}
			typedisplayed = true;
			pOSafe->Release();
		}

		sprintf(regkey, "Software\\Classes\\CLSID\\%s\\Implemented Categories\\{7DD95801-9882-11CF-9FA9-00AA006C42C4}", argv[2]);
		LONG retValScripting = RegOpenKeyEx(HKEY_LOCAL_MACHINE, regkey, 0, KEY_QUERY_VALUE, &hKeyQ );
		RegCloseKey(hKeyQ);
		sprintf(regkey, "Software\\Classes\\CLSID\\%s\\Implemented Categories\\{7DD95802-9882-11CF-9FA9-00AA006C42C4}", argv[2]);
		LONG retValIniting = RegOpenKeyEx(HKEY_LOCAL_MACHINE, regkey, 0, KEY_QUERY_VALUE, &hKeyQ );
		RegCloseKey(hKeyQ);

		if (retValIniting == ERROR_SUCCESS || retValScripting == ERROR_SUCCESS)
		{
			if (retVal == ERROR_SUCCESS)
			{
				printf("\n+ %s\n", (char*)rData);
				printf("     %s\n", argv[2]);
			}
			else
				printf("\n+ %s\n", argv[2]);
		
			printf("     Implemented Categories:\n");
			if (retValIniting == ERROR_SUCCESS)
				printf("     Category: Safe for Initialising\n");

			if (retValScripting == ERROR_SUCCESS)
				printf("     Category: Safe for Scripting\n");

			if (!typedisplayed)
			{
				IDispatch *dptr;
				hr = CoCreateInstance(clsid, NULL, CLSCTX_LOCAL_SERVER | CLSCTX_INPROC_SERVER, IID_IDispatch, (void**)&dptr);
				if (hr == S_OK)
				{
					displayTypeInfo(dptr);
					fuzzdispatch(dptr);
					dptr->Release();
				}
			}
		}
		
	//} catch (...)
	//{
	//An exception in a COM server can sometimes be used as an DoS, depending if
	//if its caught by IE gracefully or not.
	//	printf("\n* Exception occurred **** \n**** %s\n", argv[2]);
	//	if (retVal == ERROR_SUCCESS)
	//		printf("**** %s\n\n", (char*)rData);
	//}
	
	CoUninitialize();
	return 0;
}