// FuncDesc.cpp: implementation of the CFuncDesc class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "FuncDesc.h"

extern CVarFuzz fuzzVar;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CFuncDesc::CFuncDesc(bool bDisplay)
: m_NbNames(0),m_Names(NULL),m_ArgTypes(NULL),m_ArgDispId(NULL),m_NbParams(0)
, m_bIgnore(false),m_CurrCount(0),m_bDisplay(bDisplay)
{
	m_Doc = SysAllocString(L"");
}

CFuncDesc::CFuncDesc(const CFuncDesc &fd)
{
	m_MemberId = fd.m_MemberId;
	m_NbParams = fd.m_NbParams;
	m_NbOptParams = fd.m_NbOptParams;
	m_InvKind = fd.m_InvKind;
	m_FuncKind = fd.m_FuncKind;
	m_RetType = fd.m_RetType;
	m_NbNames = fd.m_NbNames;
	m_bIgnore = fd.m_bIgnore;
	m_Doc = SysAllocString(fd.m_Doc);
	m_CurrCount = fd.m_CurrCount;
	m_bDisplay = fd.m_bDisplay;
	if (m_NbParams>0)
	{
		m_ArgTypes = new VARTYPE[m_NbParams];
		memcpy(m_ArgTypes,fd.m_ArgTypes,sizeof(VARTYPE)*m_NbParams);
	}
	else
	{
		m_ArgTypes = NULL;
	}

	if (m_NbNames>0)
	{
		m_Names = new BSTR[m_NbNames];
		for (unsigned short i = 0; i<m_NbNames;i++)
		{
			m_Names[i] = SysAllocString(fd.m_Names[i]);
		}

		m_ArgDispId = new MEMBERID[m_NbNames];
		memcpy(m_ArgDispId,fd.m_ArgDispId,sizeof(MEMBERID)*m_NbNames);
	}
	else
	{
		m_Names = NULL;
		m_ArgDispId = NULL;
	}
}

CFuncDesc::~CFuncDesc()
{
	delete []m_ArgTypes;

	for (unsigned int i=0; i<m_NbNames;i++)
		SysFreeString(m_Names[i]);
	delete []m_Names;
	delete []m_ArgDispId;

	SysFreeString(m_Doc);
}

void CFuncDesc::SetFuncDesc(_bstr_t *progId,FUNCDESC *fd,ITypeInfo  *ti, _bstr_t*FN)
{
	m_FuncKind = fd->funckind;
	m_InvKind = fd->invkind;
	m_NbParams = fd->cParams;
	m_NbOptParams = fd->cParamsOpt;
	m_MemberId = fd->memid;
	m_RetType = fd->elemdescFunc.tdesc.vt;

	m_ArgTypes = new VARTYPE[m_NbParams];
	for (unsigned int i=0;i<m_NbParams;i++)
		m_ArgTypes[i]= fd->lprgelemdescParam[i].tdesc.vt;

	m_Names = new BSTR[m_NbParams+1];
	SysFreeString(m_Doc);
	HRESULT hr = ti->GetDocumentation(m_MemberId,NULL,&m_Doc,NULL,NULL);

	hr = ti->GetNames( m_MemberId, m_Names,m_NbParams+1, &m_NbNames);

	_bstr_t n(m_Names[0]);
	m_bIgnore = fuzzVar.Ignore(*progId,n);
	
	if (FN && SysStringLen(*FN)>0 && _wcsicmp(*FN,m_Names[0]))
		m_bIgnore = true;

	m_ArgDispId = new MEMBERID[m_NbNames];
	hr = ti->GetIDsOfNames(m_Names, m_NbNames,m_ArgDispId);


}

#define cbMaxSz 2048

void CFuncDesc::PrintName() const
{
	wcout << m_Names[0];
}

void CFuncDesc::Print( VARIANTARG *pVars) const
{
	if(!m_bDisplay) return;
	
	WCHAR szString[cbMaxSz];

	if (m_FuncKind <= FUNC_DISPATCH)
	{
		LoadStringW(NULL,IDS_FUNCKIND+m_FuncKind, szString, cbMaxSz);
		wcout  << szString;
	}
	else
		wcout << L"TODO:UNKNOWN FUNC KIND ";

	if (m_InvKind <= INVOKE_PROPERTYPUTREF)
	{
		LoadStringW(NULL,IDS_INVKIND+m_InvKind, szString, cbMaxSz);
		wcout << szString;
	}
	else
		wcout << L"TODO:UNKNOWN INVOKE KIND ";

	PrintVarType(m_RetType);

	wcout << m_Names[0];

	//arguments
	wcout << L"(";
	bool bOpt;
	for (unsigned short j = 0; j<m_NbParams;j++)
	{
		bOpt = false;
		if (pVars == NULL && m_NbOptParams>0)
		{
			if (j>=m_NbParams-m_NbOptParams)
				bOpt = true;
		}
		if (bOpt) wcout << L"[";

		if (m_ArgTypes[j] >=100)
			wcout << L"TODO:WARNING!!!!" << endl;
		
		if (pVars == NULL )
		{
            PrintVarType(m_ArgTypes[j],NULL);
			if (j+1<(unsigned short)m_NbNames)
			{
				wcout << L" " << m_Names[j+1];
			}
		}
		else
			PrintVarType(m_ArgTypes[j],&pVars[j]);


		if (bOpt) 
			wcout << L"] "; 
		else 
			wcout << L" ";
		if (j<m_NbParams-1)
			wcout << L",";

	}
	wcout << L")";
	
	if (pVars == NULL )
	{
		if (m_Doc && wcslen(m_Doc)>0)
			wcout << endl << L"\t" << m_Doc;


		wcout << endl;
	}
}

DWORD CFuncDesc::GetNbCombinations()
{

	if (m_bIgnore==true)
		return 0;
	else if (m_NbParams==0)
		return 1;
	else
	{
		DWORD total=1;
		for (unsigned int i=0;i<m_NbParams;i++)
			total*=fuzzVar.GetNbCombinations(m_ArgTypes[i]);
		return (total>fuzzVar.GetMaxComb()?fuzzVar.GetMaxComb():total);
	}
}

void CFuncDesc::FuzzFunction(ITypeInfo *pTI,VOID FAR*  pvInstance,CDispMap *rlist,CDispSet *pList )
{
	m_rlist = rlist;
	m_plist = pList;
	if (m_bIgnore==true)
	{
		if(m_bDisplay)
		{
			wcout << L"IGNORING: ";
			Print();
			wcout << endl;
		}
		return;
	}

	VARIANTARG *pRunVars;
	CVarList **VarList = new CVarList*[m_NbParams];

	pRunVars = new VARIANTARG[m_NbParams];


	for (unsigned int i=0;i<m_NbParams;i++)
	{
		VarList[i] = fuzzVar.GetCombinations(m_ArgTypes[i]);
	}

	if(m_bDisplay)
	{
		wcout << endl << endl;
	}
//	unsigned j = 0;

	m_CurrCount =0;
	if (m_NbParams>0)
	{
		ExecuteFuzz(pTI,pvInstance,pRunVars,VarList,0);
	}
	else
	{
		Execute1Fuzz(pTI,pvInstance,pRunVars);
	}
	delete []pRunVars;
	delete []VarList;

}

// Outputs to stdout the vartype
void CFuncDesc::PrintVarType(VARTYPE vt, VARIANTARG *v,unsigned int truncate) const
{
	if(!m_bDisplay) return;
	if (v==NULL)
	{
		if (vt & VT_VECTOR	)
		{ 
			wcout << L"VECTOR ";
		}
		if (vt & VT_ARRAY)
		{
			wcout << L"ARRAY ";
		}
		if (vt & VT_BYREF)
		{
			wcout << L"BYREF ";
		}
		if (vt & VT_RESERVED)
		{
			wcout << L"RESERVED ";
		}

		WCHAR szString[cbMaxSz];

		if ((vt & VT_TYPEMASK) <= VT_CLSID)
		{
			LoadStringW(NULL,IDS_TYPEDEF+(vt & VT_TYPEMASK), szString, cbMaxSz);
			wcout << szString;
		}
		else
			wcout << L"TODO:UNKNOWN VARTYPE";
	}
	else
	{
			if (vt & VT_VECTOR	)
		{ 
			wcout << L"VECTOR ";
		}
		if (vt & VT_ARRAY)
		{
			wcout << L"ARRAY ";
			
			SAFEARRAY* pSA;
			pSA = v->parray;
			long lBound;
			long uBound;
			if (FAILED(SafeArrayGetUBound(pSA, 1, &uBound)))
			{
				exit(-10);
			}
			if (uBound==-1)
				uBound = pSA->cbElements-1;
			SafeArrayGetLBound(pSA, 1, &lBound);

			long ans = 0;
			_variant_t var;

			wcout << L"[ ";
			for(long j = lBound; j <= uBound; j++)
			{
				SafeArrayGetElement(pSA, &j, &var);
				PrintVarType(v->vt & VT_TYPEMASK,&var);
			wcout << L" , ";
			}
			wcout << L"]";
			return;

		}
		if (vt & VT_BYREF)
		{
			wcout << L"BYREF ";
		}
		if (vt & VT_RESERVED)
		{
			wcout << L"RESERVED ";
		}

		_variant_t vv(*v,true);
		if ((v->vt & VT_TYPEMASK)!= VT_BSTR)
		{
			if (vv.vt == VT_DISPATCH)
			{
				vv = _bstr_t(L"VT_DISPATCH");
			}
			else if (vv.vt == VT_UNKNOWN)
			{
				vv = _bstr_t(L"VT_UNKNOWN");
			}
			else if (vv.vt == VT_NULL)
			{
				vv = _bstr_t(L"VT_NULL");
			}
			else
			{
				vv.ChangeType(VT_BSTR);
			}
			if (wcslen(vv.bstrVal)>20)
			{
				size_t l = wcslen(vv.bstrVal)/1024;
				wchar_t c = vv.bstrVal[15];
				vv.bstrVal[15]=NULL;
				wcout << vv.bstrVal << L"(" << l << L"k)" ; 
				vv.bstrVal[15] = c;
			}
			else
				wcout << vv.bstrVal ; 
		}
		else
			if ((truncate>0) && (wcslen(vv.bstrVal)>truncate))
			{
				size_t l = wcslen(vv.bstrVal)/1024;
				wchar_t c = vv.bstrVal[truncate+1];
				vv.bstrVal[truncate+1]=NULL;
				wcout << vv.bstrVal << L"(" << l << L"k)" ; 
				vv.bstrVal[truncate+1] = c;
			}
			else
				wcout << L"\"" << vv.bstrVal << L"\""; 


	}
}


void CFuncDesc::Execute1Fuzz(ITypeInfo *pTI,VOID FAR*  pvInstance,VARIANTARG *pBVars)
{
	_variant_t vResult;
	unsigned int ArgErr;
	EXCEPINFO ex;
	try
	{
		VARIANTARG *pRunVars = NULL;

		DISPPARAMS DispParams;

		DispParams.cArgs = m_NbParams;
		DispParams.cNamedArgs = m_NbNames-1;
		if (m_NbNames ==1)
			DispParams.rgdispidNamedArgs = NULL;
		else
		DispParams.rgdispidNamedArgs = &m_ArgDispId[1];

		if (m_NbParams>0)
		{
			pRunVars = new VARIANTARG[m_NbParams];
			for (int i=0;i<m_NbParams;i++)
			{
	//			VariantClear(&pRunVars[i]);
				if (pRunVars[i].vt == VT_PTR)
				{ 
					TYPEDESC *pt= (TYPEDESC *)&pRunVars[i];
					pt->lptdesc = NULL;
				}
				else
				{
					VariantInit(&pRunVars[i]);
					::VariantCopy(&pRunVars[i],&pBVars[i]);
				}
			}
			DispParams.rgvarg = pRunVars;
			Print(pRunVars);
		}
		else
		{
			DispParams.rgvarg = NULL;
			Print(&vResult);
		}

		HRESULT hr = pTI->Invoke( pvInstance,     
					m_MemberId,           
					m_InvKind,    
					&DispParams,  
					&vResult,  
					&ex, 
					&ArgErr);
		if (m_RetType != VT_VOID && m_bDisplay)
		{
			wcout << L" = ";

			// If IDispatch type, add to list
			if (vResult.vt == VT_DISPATCH)
			{
				if (vResult.pdispVal != NULL) 
				{
					if (vResult.pdispVal != pvInstance)
					{
						IDispatch * p = vResult.pdispVal;
						ITypeInfo  *pTypeInfo;
						if (!FAILED(p->GetTypeInfo(0, NULL, &pTypeInfo)))
						{
							BSTR pBstrName;           
							if (!FAILED(pTypeInfo->GetDocumentation(MEMBERID_NIL,&pBstrName,NULL,NULL,NULL)))
							{
								if (m_plist->find(pBstrName)== m_plist->end())
								{
									if (m_rlist->find(pBstrName)== m_rlist->end())
									{
										p->AddRef();
										
										m_rlist->operator [] (_bstr_t(pBstrName,true)) = vResult.pdispVal;

									}
								}
							}
						}
						pTypeInfo->Release();

					}
					else
					{
						//trying to add same...
						int x = 1;
					}
				}
			}

			PrintVarType(vResult.vt,(VARIANTARG *)&vResult,fuzzVar.GetTruncateOut());
		}
		if (hr ==DISP_E_EXCEPTION)
		{
			// output exception info
			if (ex.bstrDescription)
				wcout << L"\tEXCEPTION:" << ex.bstrDescription;
			else
				wcout << L"\tUNKNOWN EXCEPTION:" << ex.scode; 
		}
		if (m_NbParams>0)
		{
			for (int i=0;i<m_NbParams;i++)
			{
				if (_variant_t(pRunVars[i]) != variant_t(pBVars[i]))
				{
					wcout << L"VARIABLE CHANGED";
				}
			}
			DispParams.rgvarg = pRunVars;
		}
		wcout << endl;

		delete []pRunVars;

	}
	catch (exception e)
	{
		wcout << L"exception....";
	}
}

bool CFuncDesc::ExecuteFuzz(ITypeInfo *pTI,VOID FAR*  pvInstance,VARIANTARG *pRunVars,CVarList **VarList,unsigned int i)
{
	try
	{
		for (unsigned int x=0;x<VarList[i]->size();x++)
		{
	//		VariantClear(&pRunVars[i]);
			VariantInit(&pRunVars[i]);
			pRunVars[i] = VarList[i]->operator [](x);
					
			if (m_CurrCount>fuzzVar.GetMaxComb())
			{
				wcout << L"MAX COUNT REACHED - IGNORING rest of combinations" << endl;
				return false;
			}
			if (i == m_NbParams	-1)
			{
				m_CurrCount++;
				Execute1Fuzz(pTI,pvInstance,pRunVars);
			}
			else
			{
				if (ExecuteFuzz(pTI,pvInstance,pRunVars,VarList,i+1)==false)
					return false;
			}
		}
	}
	catch (exception e)
	{
		wcout << L"CRASH!!!!" << endl;
	}
	return true;
}

void CFuncDesc::SetDisplay(bool bDisplay){
	m_bDisplay = bDisplay;
}
