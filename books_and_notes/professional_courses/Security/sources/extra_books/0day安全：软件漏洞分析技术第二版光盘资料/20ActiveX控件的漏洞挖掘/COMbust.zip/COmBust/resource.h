//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ComBust.rc
//

#include "combust.h"


#define IDS_FUNCKIND                    101
#define IDS_FUNCKIND2                   102
#define IDS_FUNCKIND3                   103
#define IDS_FUNCKIND4                   104
#define IDS_FUNCKIND5                   105
#define IDS_INVKIND                     200
#define IDS_INVKIND1                    201
#define IDS_INVKIND2                    202
#define IDS_INVKIND4                    204
#define IDS_INVKIND8                    208
#define IDS_TYPEDEF                     300
#define IDS_VT_EMPTY                    300
#define IDS_VT_NULL                     301
#define IDS_VT_I2                       302
#define IDS_VT_I4                       303
#define IDS_VT_R4                       304
#define IDS_VT_R8                       305
#define IDS_VT_CY                       306
#define IDS_VT_DATE                     307
#define IDS_VT_BSTR                     308
#define IDS_VT_DISPATCH                 309
#define IDS_VT_ERROR                    310
#define IDS_VT_BOOL                     311
#define IDS_VT_VARIANT                  312
#define IDS_VT_UNKNOWN                  313
#define IDS_VT_DECIMAL                  314
#define IDS_VT_I1                       316
#define IDS_VT_UI1                      317
#define IDS_VT_UI2                      318
#define IDS_VT_UI4                      319
#define IDS_VT_I8                       320
#define IDS_VT_UI8                      321
#define IDS_VT_INT                      322
#define IDS_VT_UINT                     323
#define IDS_VT_VOID                     324
#define IDS_VT_HRESULT                  325
#define IDS_VT_PTR                      326
#define IDS_VT_SAFEARRAY                327
#define IDS_VT_CARRAY                   328
#define IDS_VT_USERDEFINED              329
#define IDS_VT_LPSTR                    330
#define IDS_VT_LPWSTR                   331
#define IDS_VT_RECORD                   336
#define IDS_VT_FILETIME                 364
#define IDS_VT_BLOB                     365
#define IDS_VT_STREAM                   366
#define IDS_VT_STORAGE                  367
#define IDS_VT_STREAMED_OBJECT          368
#define IDS_VT_STORED_OBJECT            369
#define IDS_VT_BLOB_OBJECT              370
#define IDS_VT_CF                       371
#define IDS_VT_CLSID                    372
#define IDI_ICON1                       400

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        401
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
