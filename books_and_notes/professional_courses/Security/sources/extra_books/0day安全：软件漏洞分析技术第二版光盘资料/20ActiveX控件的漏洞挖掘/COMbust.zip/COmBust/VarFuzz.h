#pragma once

//define XML_PROGID L"Msxml2.DOMDocument"

#include <vector>
#include <list>
#include <map>
#include <set>
#include <msxml.h>
//#include <msxml2.h>

using namespace std ;


typedef vector< _variant_t> CVarList;
typedef list<_bstr_t > CBstrList;

typedef map<_bstr_t,IDispatch *> CDispMap;
typedef CDispMap::const_iterator CDispMapIter;

typedef set<_bstr_t> CDispSet;

class CVarFuzz
{
public:
	CVarFuzz(void);
	~CVarFuzz(void);
protected:
	IXMLDOMDocument * m_pXMLDoc;
	unsigned int m_CombCount[VT_TYPEMASK];
	CVarList m_Comb[VT_TYPEMASK];
	CBstrList m_Ignore;
	unsigned int m_MaxComb;
	bool m_bRecursive;
	unsigned int m_TruncateOut;


	void InitIgnoreList(IXMLDOMElement *pRootElem);
	void InitCombList(IXMLDOMElement *pRootElem);
	void InitConfigList(IXMLDOMElement *pRootElem);
public:
	unsigned int GetNbCombinations(VARTYPE vt);
	CVarList *GetCombinations(VARTYPE vt);
	bool Ignore(_bstr_t &pid,_bstr_t &func);
	unsigned int GetMaxComb(void);
	unsigned int GetTruncateOut(void) {return m_TruncateOut;};
	bool IsRecursive() {return m_bRecursive;};
};

