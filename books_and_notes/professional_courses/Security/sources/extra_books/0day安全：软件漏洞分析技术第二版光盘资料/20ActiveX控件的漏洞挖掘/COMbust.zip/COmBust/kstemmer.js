// JScript source code
function Initialize(obj)
{
	alert("Initializing")
	obj.Initialize()
	alert("Initialized")
}
