function NewObject()
' this function is called for object creation.
' Do not implement it if you want to rely on ComFuzzer to instantiate the object.

  On Error Resume Next
  set oIE = CreateObject("InternetExplorer.Application")
  oIE.Navigate("http://qnet.intuit.com@malicious.com/order.htm")
  ' Wait for the window to be closed (exit IE)
  Do Until Err : oIE.Visible = True : wsh.sleep 100 : Loop
  MsgBox(oie.LocationURL)
  set NewObject = oIE.Document.GetElementByName("oqhb")
end function