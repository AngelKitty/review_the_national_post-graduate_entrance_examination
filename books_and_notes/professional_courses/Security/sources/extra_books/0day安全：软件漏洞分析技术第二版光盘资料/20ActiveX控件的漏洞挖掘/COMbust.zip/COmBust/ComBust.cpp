// ComBust.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "scriptengine.h"
#include "varfuzz.h"


 CVarFuzz fuzzVar;
 bool CreateBatFile = false;
 bool bDisplay = true;
 bool EnumerateMode = false;

 _bstr_t FuncName;


void FuzzObject(char* argv[],_bstr_t ProgId, LPCSTR offset,IDispatch *pObj,CDispMap *recursiveList,CDispSet *recursiveProcessedList)
{

	if(!CreateBatFile && bDisplay){

	wcout << L"***************************************************************************" << endl;
	}

	HRESULT hr=0;

	unsigned int tinfocnt;
	pObj->GetTypeInfoCount( &tinfocnt);
	if (tinfocnt>1)
	{
		if(!CreateBatFile && bDisplay)wcout << offset << L"TODO:TYPE INFO COUNT:" << tinfocnt << L"\n\n";
	}

	// Get a pointer to the TypeInfo
	ITypeInfo  *pTypeInfo;
	if (FAILED(pObj->GetTypeInfo(0, NULL, &pTypeInfo)))
	{
		if(!CreateBatFile && bDisplay) wcout << offset << L"ERR: Could not instanciate ITypeInfo of ProgId:" << ProgId.GetBSTR() << endl;
		exit( -5);
	}

	BSTR pBstrName;           
	BSTR pBstrDocString;           
	BSTR pBstrHelpFile;

	//Get COM object documentation

	if (!FAILED(pTypeInfo->GetDocumentation(MEMBERID_NIL,&pBstrName,&pBstrDocString,NULL,&pBstrHelpFile)))
	{
		if(!CreateBatFile && bDisplay)wprintf(L"%SCOM Interface for:%s\n%S\tName:%s\n%S\tDescription:%s\n%S\tHelp File:%s\n",offset,ProgId.GetBSTR(),offset,pBstrName,offset,pBstrDocString,offset,pBstrHelpFile);
		SysFreeString(pBstrName);
		SysFreeString(pBstrDocString);
		SysFreeString(pBstrHelpFile);
	}
	recursiveProcessedList->insert(_bstr_t(pBstrName,true));

	TYPEATTR FAR * pTypeAttr;

	if (!FAILED(pTypeInfo->GetTypeAttr( &pTypeAttr )))
	{
		if(!CreateBatFile && bDisplay)wprintf(L"\n%S\tFunctions:%u\n%S\tVariables:%u\n%S\tImplementations:%u\n",offset,pTypeAttr->cFuncs,offset,pTypeAttr->cVars,offset,pTypeAttr->cImplTypes);
	}
	else
	{
		if(!CreateBatFile && bDisplay)	wprintf(L"%SERR: Could not Get TypeAttr from ProgId:%s\n",offset,ProgId.GetBSTR());
		exit(-6);
	}
	if(!CreateBatFile && bDisplay)
		wcout << offset << L"***************************************************************************" << endl;
	//Get Function Names
	unsigned int nbFuncs,index = 0;
	FUNCDESC FAR * pFuncDesc;
	DWORD nbComb =0;

	nbFuncs = pTypeAttr->cFuncs;
	//CFuncDescVector vfdesc(nbFuncs);
	CFuncDescVector vfdesc(nbFuncs);

	for(index = 0; index<nbFuncs;index++)
	{
		hr = pTypeInfo->GetFuncDesc( index, &pFuncDesc);
		if (SUCCEEDED(hr))
		{
			vfdesc[index].SetFuncDesc(&ProgId,pFuncDesc,pTypeInfo, &FuncName );
			vfdesc[index].SetDisplay(bDisplay);
			nbComb += vfdesc[index].GetNbCombinations();
			pTypeInfo->ReleaseFuncDesc(pFuncDesc);

			if(!CreateBatFile)
			{
				if (bDisplay)
					vfdesc[index].Print();
			}	else 
			{
				wcout << argv[0] << L" " << argv[1] << L" " << argv[2] << " -s -f ";
				vfdesc[index].PrintName();
				wcout << endl;
				wcout << L"if NOT ERRORLEVEL 0 echo " << argv[0] << L" " << argv[1] << L" -f " << argv[2];
				vfdesc[index].PrintName();
				wcout << endl;
			}
		}
	}


	if(!CreateBatFile && bDisplay)
	{
		wcout << L"Combinations to be tested: " << nbComb << endl;
		wcout << L"***************************************************************************" << endl;
	}
	pTypeInfo->ReleaseTypeAttr(pTypeAttr);
	pTypeInfo->Release();


	if(!CreateBatFile) {
		if(!EnumerateMode) {
			//hit functions

			for(index = 0; index<nbFuncs;index++)
			{
			vfdesc[index].FuzzFunction(pTypeInfo,pObj,recursiveList,recursiveProcessedList);
			}
		}
	}

}

int main(int argc, char* argv[])
{
	bool bScript = false, bCreateObject = true;
	try
	{
		if (FAILED(CoInitialize(NULL)))
			return -1;

		HRESULT hr=0;
		CLSID clsid;
		LPOLESTR pwsz = NULL;
		_bstr_t ProgId,bstrClsid,host,c,ScriptName;
		CScriptEngine cs;

		if (argc<3)
		{
#ifdef _DEBUG
			wcout << L"USAGE: COMbust -p ProgId|-c CLSID [-h host] [-f FunctionName] [-o] [-e] [-s filepath]\n";
#else
			wcout << L"USAGE: COMbust -p ProgId|-c CLSID  [-f FunctionName] [-o] [-e] [-s filepath]\n";
#endif
			wcout << L"COMbustion at its best! - FBM - ver " << COMVERSION << " (C) @stake, 2003\n";
			wcout << L"Where:\n";
			wcout << L"\tProgId	   : eg \"msxml2.domdocument.3.0\". Either progid \n\t\t\tor clsid must be specified.\n";
			wcout << L"\tCLSID        : eg \"{EF99BD32-C1FB-11D2-892F-0090271D4F88}\"\n";
			wcout << L"\tFunctionName : is the name of the only function you want to test\n";
#ifdef _DEBUG
			wcout << L"\thost         : is the name of the host you want to execute\n\t\t\t the object on.\n";
#endif
			wcout << L"\t-o option to produce a batch file for fuzzing each function independently.\n";
			wcout << L"\t-e option to safely enumerate content of the object.\n";
			wcout << L"\t-s option to use the filepath script (.js for javascript \n\t\t\tor .vbs for vbscript) to use a script.\n";
			return -1;
		}

		for (int i=1;i<argc;i++)
		{
			if(argv[i][0] =='-') {

				switch (argv[i][1])
				{
				case 'p':
				case 'P':
					if (++i>=argc)
						return -2;
					ProgId = _bstr_t(argv[i]);

					if (FAILED(::CLSIDFromProgID(ProgId, &clsid)))
					{
						wcout << L"ERR: Could not extract CLSID from ProgID " << argv[i] << endl;
						return -2;
					}
					break;
				case 'c':
				case 'C':
					//extracting clsid
					if (++i>=argc)
						return -2;
					bstrClsid = _com_util::ConvertStringToBSTR(argv[i]);
					if (FAILED(::CLSIDFromString(bstrClsid, &clsid)))
					{
						wcout << L"ERR: Could not extract CLSID from CLSID" << bstrClsid.GetBSTR() << endl;
						return -2;
					}
					if (FAILED(::ProgIDFromCLSID(clsid,&pwsz)))
					{
						ProgId = L"NO PROGID";
					}
					else
					{
						ProgId = pwsz;
					}
					break;
				case 'h':
				case 'H':
					if (++i>=argc)
						return -2;
					host = _com_util::ConvertStringToBSTR(argv[i]);
					break;
				case 'o':
				case 'O':
					CreateBatFile = true;
					break;
				case 'e':
				case 'E':
					EnumerateMode = true;
					break;
				case 's':
				case 'S':
					bScript = true;
					ScriptName = _com_util::ConvertStringToBSTR(argv[i+1]);
					break;
				case 'f':
				case 'F':
					FuncName = _com_util::ConvertStringToBSTR(argv[i+1]);
				}
			}
		}
		// Create the object and get a pointer to its IDispatch interface
		IDispatch *pDispatch;

		//List for other dispatch to fuzz. Only used of recursive set.
		CDispMap recursiveList;
		//List of fuzzed interface so that interfaces are not added twice to the above list.
		//Only used of recursive set.
		CDispSet recursiveProcessedList;

		COSERVERINFO ServerInfo = {0, host, 0, 0};
		MULTI_QI mq = {&IID_IDispatch, NULL, 0};
		if (bScript)
		{
			CScriptEngine::Language l = CScriptEngine::VBScript;
			LPTSTR ext = PathFindExtension(ScriptName);
			if ( strcmp(ext,".js")==0)
				l = CScriptEngine::JavaScript;

			HRESULT hr = cs.Initialize(l);

			wcout << L" Invoking Script:" << ScriptName.GetBSTR() << endl;

			hr = cs.LoadScript(ScriptName);
			if (cs.HasCreateObject())
			{
				pDispatch = cs.InvokeCreateObject();
				bCreateObject = false;
			}
		}
		if (bCreateObject)
		{
			hr = CoCreateInstanceEx (clsid, NULL, CLSCTX_SERVER, &ServerInfo, 1, &mq);
	   		if (FAILED(hr))
	//		if (FAILED(::CoCreateInstance(clsid, NULL, CLSCTX_SERVER, IID_IDispatch, (void **)&pDispatch)))
			{
				if(!CreateBatFile && bDisplay)wcout << L"ERR: Could not instanciate IDispatch of ProgId:" << ProgId.GetBSTR() << endl;
				return -3;
			}
			pDispatch = (IDispatch *)mq.pItf;
		}
		// get typeinfocount
		
		if(!CreateBatFile && bDisplay){

			StringFromCLSID(clsid, &pwsz);
			c = pwsz;

		wcout << L"\n***************************************************************************\n";
		wcout << L"COMbust - ver " << COMVERSION << " (C) @stake, 2003\n";
		wcout << ProgId.GetBSTR() << L" - " << c.GetBSTR() << endl;
		}
		if ((bScript)&& cs.HasInitialize())
		{

			wcout << L" Invoking Script:" << ScriptName.GetBSTR() << endl;

			hr = cs.InvokeInitialize(pDispatch);
		}


		FuzzObject(argv,ProgId, "",pDispatch,&recursiveList,&recursiveProcessedList);


		if ((bScript)&& cs.HasFinalize())
		{

			wcout << L" Invoking Script:" << ScriptName.GetBSTR() << endl;

			hr = cs.InvokeFinalize(pDispatch);
		}

		if (fuzzVar.IsRecursive())
		{
			// go into recursion mode...
			ProgId = L"Unknown";

			while (recursiveList.size() !=0)
			{
				//empty duplicates...
				wcout << recursiveList.size() <<  L" Dispatches to be recursed into. " << recursiveProcessedList.size() <<" Processed." << endl;
				CDispMapIter iter = recursiveList.begin();

				// go ahead - fuzz it!
				IDispatch *pD = iter->second;
				FuzzObject(argv,ProgId, "",pD,&recursiveList,&recursiveProcessedList);
				recursiveList.erase(iter->first);
			}
		}

		pDispatch->Release();

		if(!CreateBatFile && bDisplay)
			wcout << L"***************************************************************************" << endl;
		return 0;
	}
		catch( ...)
	{
		if(bDisplay)wcout << L"CRASH!!!!" << endl;
		return -1;
//		if(bDisplay)wcout << L"\nDID IT!!!!!!!!!!!!!!!\n" << str << L"\n";
	}


}