// FuncDesc.h: interface for the CFuncDesc class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FUNCDESC_H__96247638_6821_4E7D_951B_B26A818AD7DE__INCLUDED_)
#define AFX_FUNCDESC_H__96247638_6821_4E7D_951B_B26A818AD7DE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "varfuzz.h"

using namespace std ;

class CFuncDesc  
{
public:
	CFuncDesc(bool bDisplay=true);
	CFuncDesc(const CFuncDesc &fd);

	void FuzzFunction(ITypeInfo  *pTI,VOID FAR*  pvInstance,CDispMap * rlist,CDispSet *pList );
	DWORD GetNbCombinations();
	void SetFuncDesc(_bstr_t *progId,FUNCDESC *fd,ITypeInfo  *ti, _bstr_t*FN);
	void SetDisplay(bool bDisplay);

	virtual ~CFuncDesc();
	
	void Print(VARIANTARG *pVars = NULL) const;
	void PrintName() const;

protected:
	void PrintVarType(VARTYPE vt, VARIANTARG *v= NULL,unsigned int truncate = 20) const;
	void Execute1Fuzz(ITypeInfo *pTI,VOID FAR*  pvInstance,VARIANTARG *pBVars);
	bool ExecuteFuzz(ITypeInfo *pTI,VOID FAR*  pvInstance,VARIANTARG *pRunVars,CVarList **VarList,unsigned int i);

	MEMBERID m_MemberId;
	unsigned short m_NbParams,m_NbOptParams;
	unsigned short m_InvKind;
	unsigned short m_CurrCount;
	FUNCKIND m_FuncKind;
	VARTYPE m_RetType;
	// Outputs to stdout the vartype
	unsigned int m_NbNames;
	BSTR m_Doc;
	BSTR *m_Names;
	MEMBERID *m_ArgDispId;
	VARTYPE *m_ArgTypes;
	bool m_bIgnore;
	bool m_bDisplay;
	CDispMap * m_rlist;
	CDispSet *m_plist;
};

class CFuncDescVector: public vector<CFuncDesc> 
{
public:
	CFuncDescVector(unsigned int i):vector<CFuncDesc>(i){};
};

#endif // !defined(AFX_FUNCDESC_H__96247638_6821_4E7D_951B_B26A818AD7DE__INCLUDED_)
