#include "stdafx.h"
#include "varfuzz.h"


CVarFuzz::CVarFuzz(void) :m_bRecursive(false)
{
	HRESULT hr;

	//...
	hr = CoInitialize(NULL); 
	// Check the return value, hr...
	hr = CoCreateInstance(CLSID_DOMDocument, NULL, CLSCTX_INPROC_SERVER, 
		IID_IXMLDOMDocument, (void**)&m_pXMLDoc);

	VARIANT_BOOL succ;
	_bstr_t FilePath;
	WCHAR path[MAX_PATH];

	GetModuleFileNameW(NULL,    // handle to module
						path,  // path buffer
						MAX_PATH         // size of buffer
					);
	path[wcsrchr(path,'.')-path] = NULL;
	FilePath = path;
	FilePath+=L".xml";

	hr = m_pXMLDoc->load(_variant_t(FilePath),&succ);
	
	if (!succ || FAILED(hr))
	{
		IXMLDOMParseError *err;
		hr = m_pXMLDoc->get_parseError(&err);
		BSTR r;
		err->get_reason(&r);
		LONG l;
		err->get_line(&l);
		wcout << L"Error parsing xml file:" << r << L" Line Nb:" << l;
		SysFreeString(r);
		exit(-10);
	}
	else
	{
		IXMLDOMElement *pRootElem = NULL;

			//	Get root element
		hr = m_pXMLDoc->get_documentElement(&pRootElem);
		if (FAILED(hr))
			exit(-10);

		InitCombList(pRootElem);

		InitIgnoreList(pRootElem);

		InitConfigList(pRootElem);
	}

}

CVarFuzz::~CVarFuzz(void)
{
	m_pXMLDoc->Release();
}

void CVarFuzz::InitIgnoreList(IXMLDOMElement *pRootElem)
{
	// load ignore list
	IXMLDOMNode *pVar;
	IXMLDOMNodeList *clist;
	long len;
	VARIANT v;
	IXMLDOMNode *pIgnoreElem = NULL;

	HRESULT hr = pRootElem->selectSingleNode(_bstr_t(L"//Ignore"),&pIgnoreElem);
	if (FAILED(hr))
		exit(-12);
	hr=pIgnoreElem->get_childNodes(&clist);
	if (FAILED(hr))
		exit(-12);
	hr=clist->get_length(&len);
	if (FAILED(hr))
		exit(-12);

	m_Ignore = CBstrList(0);
	for (long id =0; id<len;id++)
	{
		VariantClear(&v);
		hr=clist->get_item(id,&pVar);
		if (FAILED(hr))
			exit(-12);
		DOMNodeType tpe;
		hr =pVar->get_nodeType(&tpe);
		if (FAILED(hr))
			exit(-12);
		if (tpe == NODE_ELEMENT)
		{
			hr = pVar->get_nodeTypedValue(&v);
			if (FAILED(hr))
				exit(-12);
			m_Ignore.push_back(_bstr_t(&v));
		}
	}
	m_Ignore.sort();
}

void CVarFuzz::InitConfigList(IXMLDOMElement *pRootElem)
{
	// load ignore list
	_variant_t v;
	IXMLDOMNode *pMaxElem = NULL;

	HRESULT hr = pRootElem->selectSingleNode(_bstr_t(L"//Config/MaxCombinations"),&pMaxElem);
	if (FAILED(hr))
		exit(-13);
	VariantClear(&v);
	hr = pMaxElem->get_nodeTypedValue(&v);
	if (FAILED(hr))
		exit(-12);
	m_MaxComb = v;

	hr = pRootElem->selectSingleNode(_bstr_t(L"//Config/Recursive"),&pMaxElem);
	if (FAILED(hr))
		exit(-13);
	VariantClear(&v);
	hr = pMaxElem->get_nodeTypedValue(&v);
	if (FAILED(hr))
		exit(-12);
	m_bRecursive = v.boolVal;

	hr = pRootElem->selectSingleNode(_bstr_t(L"//Config/TruncateOut"),&pMaxElem);
	if (FAILED(hr))
		exit(-13);
	VariantClear(&v);
	hr = pMaxElem->get_nodeTypedValue(&v);
	if (FAILED(hr))
		exit(-12);
	m_TruncateOut = v.uintVal;

}

void CVarFuzz::InitCombList(IXMLDOMElement *pRootElem)
{
	// load ignore list
	IXMLDOMNode *pFuzzElem ,*pVar,*pNode,*pAttr;
	IXMLDOMNodeList *clist;
	long len;
	VARIANT v;
	HRESULT hr = pRootElem->selectSingleNode(_bstr_t(L"//Fuzz"),&pFuzzElem);
	if (FAILED(hr))
		exit(-11);

	memset(m_CombCount,0,sizeof(m_CombCount));
	

	hr = pFuzzElem->get_firstChild(&pVar);
	if (FAILED(hr))
		exit(-11);
	while (pVar)
	{	
		_bstr_t nm;
		DOMNodeType tpe;
		hr =pVar->get_nodeType(&tpe);
		if (FAILED(hr))
			exit(-11);
		if (tpe == NODE_ELEMENT)
		{
			hr=pVar->get_nodeName(&(nm.GetBSTR()));
			if (FAILED(hr))
				exit(-11);
			hr=pVar->get_childNodes(&clist);
			if (FAILED(hr))
				exit(-11);
			hr=clist->get_length(&len);
			if (FAILED(hr))
				exit(-11);

			VARTYPE vt;

			if (_wcsicmp(nm,L"VT_EMPTY")==0)
				vt = VT_EMPTY;
			else if (_wcsicmp(nm,L"VT_NULL")==0)
				vt = VT_NULL;
			else if (_wcsicmp(nm,L"VT_I2")==0)
				vt = VT_I2;
			else if (_wcsicmp(nm,L"VT_I4")==0)
				vt = VT_I4;
			else if (_wcsicmp(nm,L"VT_R4")==0)
				vt = VT_R4;
			else if (_wcsicmp(nm,L"VT_R8")==0)
				vt = VT_R8;
			else if (_wcsicmp(nm,L"VT_CY")==0)
				vt = VT_CY;
			else if (_wcsicmp(nm,L"VT_DATE")==0)
				vt = VT_DATE;
			else if (_wcsicmp(nm,L"VT_BSTR")==0)
				vt = VT_BSTR;
			else if (_wcsicmp(nm,L"VT_DISPATCH")==0)
				vt = VT_DISPATCH;
			else if (_wcsicmp(nm,L"VT_ERROR")==0)
				vt = VT_ERROR;
			else if (_wcsicmp(nm,L"VT_BOOL")==0)
				vt = VT_BOOL;
			else if (_wcsicmp(nm,L"VT_VARIANT")==0)
				vt = VT_VARIANT;
			else if (_wcsicmp(nm,L"VT_DECIMAL")==0)
				vt = VT_DECIMAL;
			else if (_wcsicmp(nm,L"VT_RECORD")==0)
				vt = VT_RECORD;
			else if (_wcsicmp(nm,L"VT_UNKNOWN")==0)
				vt = VT_UNKNOWN;
			else if (_wcsicmp(nm,L"VT_I1")==0)               
				vt = VT_I1;
			else if (_wcsicmp(nm,L"VT_UI1")==0)               //[V][T]   [S]      // Unsigned char.
				vt = VT_UI1;
			else if (_wcsicmp(nm,L"VT_UI2")==0)               //[V][T]   [S]      // 2 byte unsigned int.
				vt = VT_UI2;
			else if (_wcsicmp(nm,L"VT_UI4")==0)               //[V][T]   [S]      // 4 byte unsigned int. 
				vt = VT_UI4;
			else if (_wcsicmp(nm,L"VT_INT")==0)               //[V][T]   [S]      // Signed machine int.
				vt = VT_INT;
			else if (_wcsicmp(nm,L"VT_UINT")==0)             //[V][T]   [S]      // Unsigned machine int.
				vt = VT_UINT;
			else if (_wcsicmp(nm,L"VT_VOID")==0)             //     [T]            // C-style void.
				vt = VT_VOID;
			else if (_wcsicmp(nm,L"VT_HRESULT")==0)           //    [T]                                    
				vt = VT_HRESULT;
			else if (_wcsicmp(nm,L"VT_PTR")==0)                 // [T]            // Pointer type.
				vt = VT_PTR;
			else if (_wcsicmp(nm,L"VT_SAFEARRAY")==0)            //[T]            // Use VT_ARRAY in VARIANT.
				vt = VT_SAFEARRAY;
			else if (_wcsicmp(nm,L"VT_CARRAY")==0)               //[T]            // C-style array.
				vt = VT_CARRAY;
			else if (_wcsicmp(nm,L"VT_USERDEFINED")==0)         //[T]            // User-defined type.
				vt = VT_USERDEFINED;
			else if (_wcsicmp(nm,L"VT_LPSTR")==0)               //[T][P]         // Null-terminated string.
				vt = VT_LPSTR;
			else if (_wcsicmp(nm,L"VT_LPWSTR")==0)               //[T][P]         // Wide null-terminated string.
				vt = VT_LPWSTR;
			else if (_wcsicmp(nm,L"VT_FILETIME")==0)               //[P]         //FILETIME
				vt = VT_FILETIME;
			else if (_wcsicmp(nm,L"VT_BLOB")==0)                    // [P]         //Length prefixed bytes
				vt = VT_BLOB;
			else if (_wcsicmp(nm,L"VT_STREAM")==0)                 // [P]         //Name of the stream follows
				vt = VT_STREAM;
			else if (_wcsicmp(nm,L"VT_STORAGE")==0)                  //[P]         //Name of the storage follows
				vt = VT_STORAGE;
			else if (_wcsicmp(nm,L"VT_STREAMED_OBJECT")==0)         //[P]         //Stream contains an object
				vt = VT_STREAMED_OBJECT;
			else if (_wcsicmp(nm,L"VT_STORED_OBJECT")==0)         //[P]         //Storage contains an object
				vt = VT_STORED_OBJECT;
			else if (_wcsicmp(nm,L"VT_BLOB_OBJECT")==0)            //[P]         //Blob contains an object
				vt = VT_BLOB_OBJECT;
			else if (_wcsicmp(nm,L"VT_CF")==0)                     //[P]         //Clipboard format
				vt = VT_CF;
			else if (_wcsicmp(nm,L"VT_CLSID")==0)                  //[P]         //A Class ID
				vt = VT_CLSID;
			else if (_wcsicmp(nm,L"VT_VECTOR")==0)                  //[P]         //simple counted array
				vt = VT_VECTOR;
			else if (_wcsicmp(nm,L"VT_ARRAY")==0)            //[V]               // SAFEARRAY*.
				vt = VT_ARRAY;
			else if (_wcsicmp(nm,L"VT_BYREF")==0)            //[V]
				vt = VT_BYREF;
			else if (_wcsicmp(nm,L"VT_RESERVED")==0)
				vt = VT_RESERVED;
			else
				exit(-20);

			m_CombCount[vt]=len;
			m_Comb[vt] = CVarList(len);
			_variant_t c;
			IXMLDOMNamedNodeMap *aMap;
			for (long id =0; id<len;id++)
			{
				//VariantClear(&v);
				hr=clist->get_item(id,&pNode);
				if (FAILED(hr))
					exit(-11);
				hr = pNode->get_baseName(&(nm.GetBSTR()));
				if (FAILED(hr))
					exit(-11);
/*
				if (nm==_bstr_t(L"NULL"))
				{
					VariantInit(&c);
					VariantClear(&c);
					c.vt = vt;
					c.p

				}
				else */
				if (nm==_bstr_t(L"THIS"))
				{
					VariantInit(&v);
					VariantClear(&v);
//					v = nm;
					v.vt = vt;
					v.ppunkVal = NULL;
					VariantChangeType(&c,&c,0,vt);
				}
				else
				{
					hr = pNode->get_nodeTypedValue(&v);
					if (FAILED(hr))
						exit(-11);
					hr = pNode->get_attributes(&aMap);
					if (FAILED(hr))
						exit(-11);
					if (aMap)
					{
						hr = aMap->getNamedItem(_bstr_t(L"count"),&pAttr);
						if (FAILED(hr))
							exit(-11);
						if (pAttr)
						{
							hr=pAttr->get_nodeValue(&c);
							if (FAILED(hr))
								exit(-11);
							hr = VariantChangeType(&c,&c,0,VT_UI4);
							if (FAILED(hr))
								exit(-11);
							_bstr_t w(v.bstrVal);
							for (unsigned int x =1; 2*x <c.uintVal;x+=x)
							{
								w +=w; 
							}
							unsigned int cl = w.length();
							for (unsigned int x =cl; x <c.uintVal;x++)
							{
								w +=v.bstrVal; 
							}
							cl = w.length();
							v.bstrVal = w.copy();
						}
					}
				}
				hr = ::VariantCopy(&m_Comb[vt].at(id), &v);
				if (FAILED(hr))
					exit(-12);
				
			}
			SysFreeString(nm);
		}
		hr = pVar->get_nextSibling(&pVar);
		if (FAILED(hr))
			exit(-11);
	}
}
unsigned int CVarFuzz::GetNbCombinations(VARTYPE vt)
{
	if (vt <=VT_TYPEMASK)
	{
		if ( m_CombCount[vt]==0)
			return 1;
		else
			return m_CombCount[vt];
	}
	else
		return 0;
}

CVarList *CVarFuzz::GetCombinations(VARTYPE vt)
{
	int s = m_Comb[vt].size();
/*
	CVarList *pret = new CVarList();
	for (int i=0;i<s;i++)
	{
		pret->push_back(_variant_t(m_Comb[vt].operator [](i),true));
	}
	return pret;
*/
	_ASSERT(s>=0);
	return &m_Comb[vt];
}

bool CVarFuzz::Ignore(_bstr_t &pid,_bstr_t &func)
{
	//return false;
	bool ret = false;
	long len = m_Ignore.size();
	CBstrList::iterator iter = m_Ignore.begin();
	while(iter != m_Ignore.end())
	{
		_bstr_t tmp(*iter);
		wchar_t *tok = wcsstr(tmp,L"::");
		if (tok==NULL)
			tok = tmp;
		else
			tok+=2;
		if (_wcsicmp(func,tok)==0)
		{
			if (pid.length()==0 || tok == tmp)
			{
				return true;
			}
			else
			{
				wchar_t *t = tok;
				t-=2;
				t[0]='\0';
				if (_wcsicmp(pid,tmp)==0)
				{
					return true;
				}
			}
		}
		iter++;
	}
	return ret;
}

unsigned int CVarFuzz::GetMaxComb(void)
{
	return m_MaxComb;
}
