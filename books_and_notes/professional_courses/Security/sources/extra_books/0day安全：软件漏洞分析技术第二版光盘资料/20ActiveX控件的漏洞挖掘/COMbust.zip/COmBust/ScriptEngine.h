#pragma once

#include <activscp.h>

class CScriptEngine: public IActiveScriptSite,
						 public IActiveScriptSiteWindow
{
public:

	enum Language { VBScript, JavaScript};
	CScriptEngine(void);
	~CScriptEngine(void);

	// IUnknown Methods
	virtual HRESULT _stdcall QueryInterface(REFIID riid, void** ppvObject);
	virtual ULONG _stdcall AddRef();
	virtual ULONG _stdcall Release();

	// IActiveScriptSite methods
	virtual HRESULT _stdcall GetLCID(LCID* plcid);
	virtual HRESULT _stdcall GetItemInfo(LPCOLESTR pstrName, DWORD dwReturnMask, IUnknown** ppunkItem, ITypeInfo** ppti);
	virtual HRESULT _stdcall GetDocVersionString(BSTR* pbstrVersion);
	virtual HRESULT _stdcall OnScriptTerminate(const VARIANT* pvarResult, const EXCEPINFO* pexcepInfo);
	virtual HRESULT _stdcall OnStateChange(SCRIPTSTATE ssScriptState);
	virtual HRESULT _stdcall OnScriptError(IActiveScriptError* pScriptError);
	virtual HRESULT _stdcall OnEnterScript(void);
	virtual HRESULT _stdcall OnLeaveScript(void);

	// IActiveScriptSiteWindow methods
	virtual HRESULT _stdcall GetWindow(HWND* phWnd);
	virtual HRESULT _stdcall EnableModeless(BOOL fEnable);

protected:
	IActiveScript*		m_iActiveScript;
	IActiveScriptParse*	m_iActiveScriptParse;
	IDispatch*			m_pScriptDispatch;

	ULONG	m_dwRef;
	HWND	m_hWnd;

	HRESULT GetIDOfFunction(BSTR strFunctionName, DISPID* pID);
public:
	HRESULT Initialize(Language lg);
	HRESULT LoadScript(BSTR Script);
	HRESULT InvokeInitialize(IDispatch *pid);
	HRESULT InvokeFinalize(IDispatch *pid);
	bool HasCreateObject(void);
	bool HasInitialize(void);
	bool HasFinalize(void);
	IDispatch * InvokeCreateObject(void);
};
