#include "StdAfx.h"
#include "scriptengine.h"
#include <fstream>

CScriptEngine::CScriptEngine(void)
{
	m_iActiveScript = NULL;
	m_iActiveScriptParse = NULL;
	m_pScriptDispatch         = NULL;

	m_dwRef = 1;
	m_hWnd  = NULL;
}

CScriptEngine::~CScriptEngine(void)
{
}

HRESULT CScriptEngine::QueryInterface(REFIID riid, void** ppvObject)
{
	HRESULT		hResult = S_OK;

	if (riid == IID_IActiveScriptSiteWindow) {
		*ppvObject = (IActiveScriptSiteWindow *) this;
	} else {
		*ppvObject = NULL;
		hResult = E_NOTIMPL;
	}

	return hResult;
}

ULONG CScriptEngine::AddRef()
{
	return ++m_dwRef;
}

ULONG CScriptEngine::Release()
{
	if (m_dwRef == 0) return 0;
	return --m_dwRef;
}

HRESULT CScriptEngine::GetLCID(LCID* plcid)
{
	return S_OK;
}

HRESULT CScriptEngine::GetItemInfo(LPCOLESTR pstrName, DWORD dwReturnMask, IUnknown** ppunkItem, ITypeInfo** ppti)
{
/*
USES_CONVERSION;
	BOOL	bFound = FALSE;

	// Is it expecting an ITypeInfo?
	if (ppti) {
		// Default to NULL
		*ppti = NULL;

		// Return if asking about ITypeInfo
		if (dwReturnMask & SCRIPTINFO_ITYPEINFO) {
			return TYPE_E_ELEMENTNOTFOUND;
		}
	}

	// Is the engine passing a IUnknown buffer?
	if (ppunkItem) {
		// Default to NULL
		*ppunkItem = NULL;

		// Is the script looking for an IUnknown from our registered list?
		if (dwReturnMask & SCRIPTINFO_IUNKNOWN) {
			for (int i = 0; i < m_ExposedObjects.GetSize(); i ++) {
				if (!m_ExposedObjects[i]->GetObjectName().CompareNoCase(OLE2T(pstrName))) {
					*ppunkItem = m_ExposedObjects[i]->GetObjectInterface();
					(*ppunkItem)->AddRef();
					bFound = TRUE;
					break;
				}
			}
		}
	}

	if (! bFound) {
		return TYPE_E_ELEMENTNOTFOUND;
	}

*/
	return S_OK;
}

HRESULT CScriptEngine::GetDocVersionString(BSTR* pbstrVersion)
{
	return S_OK;
}

HRESULT CScriptEngine::OnScriptTerminate(const VARIANT* pvarResult, const EXCEPINFO* pexcepInfo)
{
	return S_OK;
}

HRESULT CScriptEngine::OnStateChange(SCRIPTSTATE ssScriptState)
{
	return S_OK;
}

HRESULT CScriptEngine::OnScriptError(IActiveScriptError* pScriptError)
{
	static BSTR		pwcErrorText;
	DWORD			contextCookie;
	ULONG			lineNumber;
	LONG			charPosition;

	pScriptError->GetSourceLineText(&pwcErrorText);
	pScriptError->GetSourcePosition(&contextCookie, &lineNumber, &charPosition);

	printf("ERROR: Script error in line %ld, position %ld  - %S\n", lineNumber, charPosition,pwcErrorText);

	if (pwcErrorText) {
		::SysFreeString(pwcErrorText);
	}

	return S_OK;
}

HRESULT CScriptEngine::OnEnterScript(void)
{
	return S_OK;
}

HRESULT CScriptEngine::OnLeaveScript(void)
{
	return S_OK;
}
HRESULT CScriptEngine::Initialize(Language lg)
{
	HRESULT		hr = S_OK;
	CLSID		clsid;

	// Find CLSID
	switch (lg)
	{
		case VBScript:
			hr = CLSIDFromProgID(L"VBScript", &clsid);
			break;
		case JavaScript:
			hr = CLSIDFromProgID(L"JavaScript", &clsid);
			break;

	}
	if (FAILED(hr)) {
		return hr;
	}

	// Start VBScript.dll (inproc server)
	hr = CoCreateInstance(
		clsid, NULL, CLSCTX_INPROC_SERVER, 
		IID_IActiveScript, (void**) &m_iActiveScript);
	if (FAILED(hr)) {
		return hr;
	}

	// QueryInterface for IActiveScriptParse
	hr = m_iActiveScript->QueryInterface(
		IID_IActiveScriptParse, (void**) &m_iActiveScriptParse);
	if (FAILED(hr)) {
		m_iActiveScript->Release();

		m_iActiveScriptParse = NULL;
		m_iActiveScript      = NULL;
		m_pScriptDispatch    = NULL;

		return hr;
	}

	// Setup our ScriptSite
	hr = m_iActiveScript->SetScriptSite(this);
	if (FAILED(hr)) {
		m_iActiveScript->Release();
		m_iActiveScriptParse->Release();

		m_iActiveScriptParse = NULL;
		m_iActiveScript      = NULL;
		m_pScriptDispatch    = NULL;

		return hr;
	}

	hr = m_iActiveScriptParse->InitNew();
	if (FAILED(hr)) {
		m_iActiveScript->Release();
		m_iActiveScriptParse->Release();

		m_iActiveScriptParse = NULL;
		m_iActiveScript      = NULL;
		m_pScriptDispatch    = NULL;

		return hr;
	}

	// Initialize m_pScriptDispatch to NULL
	m_pScriptDispatch = NULL;

	return hr;
}

HRESULT CScriptEngine::LoadScript(BSTR Script)
{
	HRESULT		hr = S_OK;
	VARIANT pvarResult; 
	EXCEPINFO	ei;
	_bstr_t		stext(L"");
	_bstr_t		path(Script);

	wifstream scriptStream(path, ios::in);
	if (!scriptStream){
		OutputDebugString("Error opening script file.\n");
		return E_FAIL;
	}

	
	while (!scriptStream.eof())
	{
		wchar_t str[1000];
		scriptStream.getline(str,1000);
		stext +=str;
		stext +=L"\n";
	}


	// This loads the script and keeps it around for the user
	// to allow to call specific methods in the script
	// Add script code to the engine
	hr = m_iActiveScriptParse->ParseScriptText(
		stext, NULL, NULL, NULL, 0, 0, SCRIPTTEXT_ISVISIBLE,  &pvarResult, &ei);
	if (FAILED(hr)) {
		m_iActiveScriptParse->Release();
		m_iActiveScript->Release();

		m_iActiveScriptParse = NULL;
		m_iActiveScript      = NULL;
		m_pScriptDispatch    = NULL;

		return hr;
	}

	// This will actually run the script
	hr = m_iActiveScript->SetScriptState(SCRIPTSTATE_CONNECTED);
	if (FAILED(hr)) {
		m_iActiveScriptParse->Release();
		m_iActiveScript->Release();

		m_iActiveScriptParse = NULL;
		m_iActiveScript      = NULL;
		m_pScriptDispatch    = NULL;

		return hr;
	}

	// We need the IDispatch for the script itself
	// to allow to use InvokeHelper
	hr = m_iActiveScript->GetScriptDispatch(0, &m_pScriptDispatch);
	if (FAILED(hr) ) {
		m_pScriptDispatch = NULL;
		return hr;
	}

	return hr;
}

HRESULT CScriptEngine::GetIDOfFunction(BSTR strFunctionName, DISPID* pID)
{
	// This method retrieves the DISPID to use when
	// calling a method in the loaded script
	// One needs to know how many parameters are used and
	// if there is a return value
	// FALSE is returned when either there is no script loaded,
	// or the method is not there.
	if (m_pScriptDispatch == NULL) {
		return E_NOTIMPL ;
	}

	HRESULT hr = S_OK;

	hr = m_pScriptDispatch->GetIDsOfNames(
		IID_NULL, 
		&strFunctionName, 
		1, 
		LOCALE_SYSTEM_DEFAULT, 
		pID);

	return hr;
}
HRESULT CScriptEngine::InvokeInitialize(IDispatch *pid)
{
	DISPID dispid;
	VARIANT	result;
	DISPPARAMS arg;
	VARIANTARG varg;
	HRESULT hr;
	if (FAILED(GetIDOfFunction(L"Initialize", &dispid))) {
		return E_NOTIMPL;
	}
	else
	{
		arg.cArgs = 1;
		arg.cNamedArgs = 0;
		arg.rgdispidNamedArgs = NULL;
		arg.rgvarg = &varg;
		varg.vt = VT_DISPATCH ;
		varg.pdispVal = pid;

		hr = m_pScriptDispatch->Invoke(dispid,IID_NULL,0, DISPATCH_METHOD, &arg,  &result, NULL,NULL);
	}
	return result.lVal;
}

HRESULT CScriptEngine::InvokeFinalize(IDispatch *pid)
{
	DISPID dispid;
	VARIANT	result;
	DISPPARAMS arg;
	VARIANTARG varg;
	HRESULT hr;
	if (FAILED(GetIDOfFunction(L"Finalize", &dispid))) {
		return E_NOTIMPL;
	}
	else
	{
		arg.cArgs = 1;
		arg.cNamedArgs = 0;
		arg.rgdispidNamedArgs = NULL;
		arg.rgvarg = &varg;
		varg.vt = VT_DISPATCH ;
		varg.pdispVal = pid;

		hr = m_pScriptDispatch->Invoke(dispid,IID_NULL,0, DISPATCH_METHOD, &arg,  &result, NULL,NULL);
	}
	return result.lVal;
}
HRESULT CScriptEngine::GetWindow(HWND* phWnd)
{
	// First try to get our active window
	HWND activeWindow = GetActiveWindow();

	// If active window results in nothing, try the application main window

	// Store window handle
	m_hWnd = activeWindow;
	*phWnd = m_hWnd;
	return S_OK;
}

HRESULT CScriptEngine::EnableModeless(BOOL fEnable)
{
	return S_OK;
}
bool CScriptEngine::HasCreateObject(void)
{
	DISPID dispid;
	if (FAILED(GetIDOfFunction(L"NewObject", &dispid))) 
		return false;
	else
		return true;
}

bool CScriptEngine::HasInitialize(void)
{
	DISPID dispid;
	if (FAILED(GetIDOfFunction(L"Initialize", &dispid))) 
		return false;
	else
		return true;
}
bool CScriptEngine::HasFinalize(void)
{
	DISPID dispid;
	if (FAILED(GetIDOfFunction(L"Finalize", &dispid))) 
		return false;
	else
		return true;
}

IDispatch * CScriptEngine::InvokeCreateObject(void)
{
	DISPID dispid;
	VARIANT	result;
	DISPPARAMS arg;
//	VARIANTARG varg;
	HRESULT hr;
	if (FAILED(GetIDOfFunction(L"NewObject", &dispid))) {
		return NULL;
	}
	else
	{
//		arg.cArgs = 1;
		arg.cArgs = 0;
		arg.cNamedArgs = 0;
		arg.rgdispidNamedArgs = NULL;
		arg.rgvarg = NULL;
/*
		arg.rgvarg = &varg;
		varg.vt = VT_DISPATCH ;
		varg.ppdispVal = NULL;
*/
		hr = m_pScriptDispatch->Invoke(dispid,IID_NULL,0, DISPATCH_METHOD, &arg,  &result, NULL,NULL);
	}
	return result.pdispVal;
}
