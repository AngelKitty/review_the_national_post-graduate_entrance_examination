#!c:\python\python.exe

#
# PyDBG Client *** NOT INCLUDED IN PUBLIC RELEASE ***
# Copyright (C) 2006 Pedram Amini <pedram.amini@gmail.com>
#

'''
@author:       Pedram Amini
@contact:      pedram.amini@gmail.com
@organization: www.openrce.org
'''

class pydbg_client:
    pass