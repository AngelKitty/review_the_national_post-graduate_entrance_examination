- These object files can be linked into your Delphi executables
  using the {$L filename.obj} directives.

- These are also used for the TMT Pascal example.
