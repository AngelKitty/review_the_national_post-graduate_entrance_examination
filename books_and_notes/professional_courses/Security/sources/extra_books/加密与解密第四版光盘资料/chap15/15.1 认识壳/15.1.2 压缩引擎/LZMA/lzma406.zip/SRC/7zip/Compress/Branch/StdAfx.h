// stdafx.h

#ifndef __STDAFX_H
#define __STDAFX_H

#include <windows.h>

#endif 
