LZMA Specification
------------------

This package contains:

  - LZMA Specification
  - LZMA Reference Decoder in C++
  - The folder with examples of lzma archives

Note that LZMA Reference Decoder is not optimized for speed.
You can use LZMA Decoder from LZMA SDK, if you need the code optimized for speed.

If you see some bug in code or errors in text of specification,
you can send a message to Igor Pavlov in support forum 
or via SourceForge email message system:

http://www.7-zip.org/support.html


---
Igor Pavlov
http://www.7-zip.org
