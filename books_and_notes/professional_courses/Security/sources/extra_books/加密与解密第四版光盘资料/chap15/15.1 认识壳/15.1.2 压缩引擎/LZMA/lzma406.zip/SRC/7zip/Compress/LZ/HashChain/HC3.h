// HC3.h

#ifndef __HC3__H
#define __HC3__H

#undef HC_CLSID
#define HC_CLSID CLSID_CMatchFinderHC3

#undef HC_NAMESPACE
#define HC_NAMESPACE NHC3

#define HASH_ARRAY_2

#include "HCMF.h"
#include "HCMFMain.h"

#undef HASH_ARRAY_2

#endif

