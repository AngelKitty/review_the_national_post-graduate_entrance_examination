// HC4.h

#ifndef __HC4__H
#define __HC4__H

#undef HC_CLSID
#define HC_CLSID CLSID_CMatchFinderHC4

#undef HC_NAMESPACE
#define HC_NAMESPACE NHC4

#define HASH_ARRAY_2
#define HASH_ARRAY_3

#include "HCMF.h"
#include "HCMFMain.h"

#undef HASH_ARRAY_2
#undef HASH_ARRAY_3

#endif

